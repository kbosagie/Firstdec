"""AI Operations Assistant — a rule-based natural-language query engine.

This intentionally does not call an external LLM API (no network access is
assumed): it recognises the shapes of question operations actually asks —
the exact examples in the FIRSTDEC brief are the primary test cases — and
answers straight from the SQLite database, returning both a plain-English
answer and (where relevant) a results table so the person can see the
underlying rows.

Swap-in point: if/when the team wants free-form NLU, `answer_query()` is the
single function to replace with an LLM-backed version — everything else
(the routes, the chat UI) stays the same.
"""
import re
from datetime import datetime, timedelta

from db.db import query
from services.reminders import ACPML_STALE_HOURS
from services.text_format import friendly_label

STATUS_ALIASES = {
    "offshore": "offshore",
    "aveon": "at_aveon",
    "acpml": "at_acpml",
    "cleaning": "cleaning",
    "ready": "ready_for_collection",
    "returned": "returned",
    "available": "available",
    "damaged": "damaged",
    "on hire": "on_hire",
}

STATUS_PHRASE = {
    "available": "available",
    "on_hire": "on hire",
    "offshore": "offshore",
    "at_aveon": "at Aveon",
    "at_acpml": "at ACPML",
    "cleaning": "in cleaning",
    "ready_for_collection": "ready for collection",
    "returned": "returned to owner",
    "damaged": "damaged",
}

DOC_TYPE_ALIASES = {
    "edn": "EDN",
    "ern": "ERN",
    "cwctn": "CWCTN",
    "disposal certificate": "WASTE_DISPOSAL_CERT",
    "disposal certificates": "WASTE_DISPOSAL_CERT",
    "waste certificate": "WASTE_DISPOSAL_CERT",
    "waybill": "WAYBILL",
    "manifest": "MANIFEST",
    "weight ticket": "WEIGHT_TICKET",
}


def _find_status(text):
    for word, status in STATUS_ALIASES.items():
        if word in text:
            return status
    return None


def _find_doc_type(text):
    for word, dtype in sorted(DOC_TYPE_ALIASES.items(), key=lambda kv: -len(kv[0])):
        if word in text:
            return dtype
    return None


def _find_owner(text):
    owners = [r["owner_name"] for r in query("SELECT DISTINCT owner_name FROM equipment")]
    for owner in owners:
        if owner.lower() in text:
            return owner
    return None


def _find_equipment_type(text):
    for t in ("skip", "skips", "tank", "tanks", "ccu", "ccus", "ibc", "ibcs", "basket", "baskets"):
        if re.search(rf"\b{t}\b", text):
            return t.rstrip("s")
    return None


def _find_project(text):
    projects = query("SELECT id, code, name, client_name FROM projects")
    for p in projects:
        for candidate in (p["code"], p["name"], p["client_name"]):
            if candidate and candidate.lower() in text:
                return p
    return None


def _equipment_table(rows):
    return {
        "columns": ["Equipment ID", "Type", "Owner", "Location", "Status", "Condition", "Project"],
        "rows": [
            [r["equipment_id"], r["equipment_type"], r["owner_name"], r["current_location"],
             STATUS_LABEL(r["current_status"]), r["condition"], r["project_name"] or "—"]
            for r in rows
        ],
    }


def STATUS_LABEL(s):
    from services.dashboard_stats import STATUS_LABELS
    return STATUS_LABELS.get(s, s)


def _document_table(rows):
    return {
        "columns": ["Type", "Number", "Counterparty", "Status", "Due", "Project"],
        "rows": [
            [r["doc_type"], r["doc_number"] or "—", r["counterparty"] or "—", r["status"].replace("_", " "),
             r["due_date"] or "—", r["project_name"] or "—"]
            for r in rows
        ],
    }


def answer_query(text):
    original = text.strip()
    q = text.lower().strip()

    project = _find_project(q)
    owner = _find_owner(q)
    etype = _find_equipment_type(q)
    status = _find_status(q)
    doc_type = _find_doc_type(q)

    # --- "generate ... report" -----------------------------------------
    if re.search(r"\b(generate|create|build)\b.*\breport\b", q) or "today's report" in q:
        period = "monthly" if "month" in q else "weekly" if "week" in q else "daily"
        proj_clause = f" for {project['name']}" if project else ""
        return {
            "answer": (
                f"I can put together a {period} operations report{proj_clause}. "
                f"Open **Reports** and choose “{period.title()} report”"
                + (f" for {project['name']}" if project else "")
                + " — it pulls equipment movements, outstanding documents, waste "
                "processed and invoicing straight from these records."
            ),
            "action": {"label": f"Go to Reports", "url": "/reports" + (f"?project_id={project['id']}" if project else "")},
        }

    # --- outstanding / awaiting waste disposal certificates --------------
    if "disposal certificate" in q or ("waste" in q and "certificate" in q):
        rows = query(
            "SELECT d.*, p.name AS project_name FROM documents d LEFT JOIN projects p ON p.id=d.project_id "
            "WHERE d.doc_type='WASTE_DISPOSAL_CERT' AND d.status != 'completed'"
        )
        if not rows:
            return {"answer": "No waste disposal certificates are outstanding right now — all are completed."}
        return {
            "answer": f"{len(rows)} waste disposal certificate(s) outstanding:",
            "table": _document_table(rows),
        }

    # --- CWCTNs awaiting signature ----------------------------------------
    if doc_type == "CWCTN" or "cwctn" in q:
        sql = ("SELECT d.*, p.name AS project_name FROM documents d LEFT JOIN projects p ON p.id=d.project_id "
               "WHERE d.doc_type='CWCTN' AND d.status='pending_signature'")
        params = ()
        if project:
            sql += " AND d.project_id = ?"
            params = (project["id"],)
        rows = query(sql, params)
        if not rows:
            return {"answer": "No CWCTNs are currently awaiting signature."}
        return {"answer": f"{len(rows)} CWCTN(s) awaiting signature:", "table": _document_table(rows)}

    # --- generic "which <doc type> are outstanding/pending" ---------------
    if doc_type and ("outstanding" in q or "pending" in q or "awaiting" in q or "not been received" in q):
        rows = query(
            "SELECT d.*, p.name AS project_name FROM documents d LEFT JOIN projects p ON p.id=d.project_id "
            "WHERE d.doc_type=? AND d.status != 'completed'", (doc_type,)
        )
        if not rows:
            return {"answer": f"No outstanding {doc_type.replace('_', ' ')} documents."}
        return {"answer": f"{len(rows)} outstanding {doc_type.replace('_', ' ')} document(s):",
                "table": _document_table(rows)}

    # --- equipment with ACPML more than 48 hours --------------------------
    if "acpml" in q and re.search(r"\b(\d+)\s*hours?\b", q) or ("acpml" in q and "more than" in q):
        hours_match = re.search(r"(\d+)\s*hours?", q)
        hours = int(hours_match.group(1)) if hours_match else ACPML_STALE_HOURS
        cutoff = (datetime.now() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
        rows = query(
            "SELECT e.*, p.name AS project_name, "
            "(SELECT MAX(m.occurred_at) FROM movements m WHERE m.equipment_id=e.id AND m.to_location='ACPML') "
            "AS since "
            "FROM equipment e LEFT JOIN projects p ON p.id = e.current_project_id "
            "WHERE e.current_status='at_acpml'"
        )
        overdue = [r for r in rows if r["since"] and r["since"] < cutoff]
        if not overdue:
            return {"answer": f"No equipment has been at ACPML for more than {hours} hours."}
        return {
            "answer": f"{len(overdue)} item(s) have been at ACPML for more than {hours} hours:",
            "table": _equipment_table(overdue),
        }

    # --- reconcile a manifest against the equipment register --------------
    if "reconcile" in q and "manifest" in q:
        target_project = project or _find_project(q)
        manifests = query(
            "SELECT d.* FROM documents d WHERE d.doc_type='MANIFEST'"
            + (" AND d.project_id=?" if target_project else ""),
            (target_project["id"],) if target_project else (),
        )
        if not manifests:
            return {"answer": "I couldn't find a matching manifest to reconcile against the register."}
        lines = []
        for m in manifests:
            linked = query(
                "SELECT e.equipment_id FROM doc_equipment de JOIN equipment e ON e.id = de.equipment_id "
                "WHERE de.document_id = ?", (m["id"],)
            )
            codes = ", ".join(r["equipment_id"] for r in linked) or "no equipment linked"
            lines.append(f"Manifest {m['doc_number']} ({m['status'].replace('_',' ')}) — register shows: {codes}")
        return {"answer": "Reconciliation against the equipment register:\n\n" + "\n".join(f"• {l}" for l in lines)}

    # --- hazardous waste tonnage this month/week ---------------------------
    if "waste" in q and ("tonnes" in q or "tons" in q or "how much" in q or "how many" in q):
        period_clause = ""
        if "month" in q:
            period_clause = " AND processing_date >= date('now','-30 days')"
        elif "week" in q:
            period_clause = " AND processing_date >= date('now','-7 days')"
        waste_type_clause = ""
        if "hazardous" in q and "non" not in q:
            waste_type_clause = " AND waste_type = 'hazardous'"
        elif "non-hazardous" in q or "non hazardous" in q:
            waste_type_clause = " AND waste_type = 'non-hazardous'"
        row = query(
            "SELECT COALESCE(SUM(net_weight_kg),0) total_kg, COUNT(*) n FROM waste_transactions "
            "WHERE 1=1" + period_clause + waste_type_clause, one=True
        )
        tonnes = (row["total_kg"] or 0) / 1000
        return {"answer": f"{tonnes:,.2f} tonnes processed across {row['n']} transaction(s) "
                           f"matching that query."}

    # --- "which skips/tanks/... are <status>" or "where are all <owner> skips" ---
    if etype or status or owner or "where are" in q:
        sql = ("SELECT e.*, p.name AS project_name FROM equipment e "
               "LEFT JOIN projects p ON p.id = e.current_project_id WHERE 1=1")
        params = []
        if etype:
            sql += " AND e.equipment_type = ?"
            params.append(etype)
        if status:
            sql += " AND e.current_status = ?"
            params.append(status)
        if owner:
            sql += " AND e.owner_name = ?"
            params.append(owner)
        rows = query(sql, tuple(params))
        if not rows:
            return {"answer": "No equipment matches that."}
        subject = f"{owner + ' ' if owner else ''}{etype + 's' if etype else 'equipment'}"
        where = f" that are {STATUS_PHRASE.get(status, status)}" if status else ""
        return {"answer": f"{len(rows)} {subject}{where}:", "table": _equipment_table(rows)}

    # --- direct equipment ID lookup ----------------------------------------
    eq_match = re.search(r"\b([A-Z]{2,6}-?\d{2,4}[A-Z]{0,3})\b", original.upper())
    if eq_match:
        row = query("SELECT e.*, p.name AS project_name FROM equipment e "
                     "LEFT JOIN projects p ON p.id = e.current_project_id WHERE e.equipment_id = ?",
                     (eq_match.group(1),), one=True)
        if row:
            docs = query(
                "SELECT d.doc_type, d.doc_number, d.status FROM documents d "
                "JOIN doc_equipment de ON de.document_id = d.id WHERE de.equipment_id = ?", (row["id"],)
            )
            doc_lines = "; ".join(f"{d['doc_type']} {d['doc_number']} ({d['status'].replace('_',' ')})"
                                   for d in docs) or "none on file"
            return {"answer": (
                f"{row['equipment_id']} — {friendly_label(row['equipment_type'])}, owned by {row['owner_name']}. "
                f"Currently {STATUS_LABEL(row['current_status']).lower()} at {row['current_location']}"
                f"{', on ' + row['project_name'] if row['project_name'] else ''}. "
                f"Condition: {row['condition']}. Documents: {doc_lines}."
            )}

    # --- fallback -----------------------------------------------------------
    return {
        "answer": "I didn't quite catch that. Try one of these:",
        "suggestions": [
            "Where are all Libroid skips?",
            "Which skips are still offshore?",
            "Show CWCTNs awaiting signature",
            "Which disposal certificates are outstanding?",
            "How many tonnes of hazardous waste have we processed this month?",
            "Which equipment has been with ACPML for more than 48 hours?",
            "Generate today's report",
        ],
    }
