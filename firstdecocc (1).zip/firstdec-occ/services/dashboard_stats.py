"""Aggregate numbers for the Operations Dashboard."""
from datetime import datetime

from db.db import query


STATUS_LABELS = {
    "available": "Available",
    "on_hire": "On Hire",
    "offshore": "Offshore",
    "at_aveon": "At Aveon",
    "at_acpml": "At ACPML",
    "cleaning": "Cleaning",
    "ready_for_collection": "Ready for Collection",
    "returned": "Returned to Owner",
    "damaged": "Damaged",
}


def get_dashboard_stats():
    active_projects = query("SELECT COUNT(*) c FROM projects WHERE status='active'", one=True)["c"]

    counts_by_status = {r["current_status"]: r["c"] for r in query(
        "SELECT current_status, COUNT(*) c FROM equipment GROUP BY current_status"
    )}
    total_equipment = sum(counts_by_status.values())
    deployed_statuses = {"offshore", "at_aveon", "at_acpml", "cleaning", "ready_for_collection", "on_hire"}
    deployed = sum(v for k, v in counts_by_status.items() if k in deployed_statuses)

    today = datetime.now().strftime("%Y-%m-%d")
    movements_today = query(
        "SELECT COUNT(*) c FROM movements WHERE substr(occurred_at,1,10) = ?", (today,), one=True
    )["c"]

    return {
        "active_projects": active_projects,
        "equipment_deployed": deployed,
        "total_equipment": total_equipment,
        "offshore": counts_by_status.get("offshore", 0),
        "at_aveon": counts_by_status.get("at_aveon", 0),
        "at_acpml": counts_by_status.get("at_acpml", 0),
        "cleaning": counts_by_status.get("cleaning", 0),
        "ready_for_collection": counts_by_status.get("ready_for_collection", 0),
        "returned": counts_by_status.get("returned", 0),
        "movements_today": movements_today,
        "counts_by_status": counts_by_status,
    }


def get_recent_movements(limit=10):
    return query(
        "SELECT m.*, e.equipment_id AS equipment_code, p.name AS project_name "
        "FROM movements m JOIN equipment e ON e.id = m.equipment_id "
        "LEFT JOIN projects p ON p.id = m.project_id "
        "ORDER BY m.occurred_at DESC LIMIT ?", (limit,)
    )
