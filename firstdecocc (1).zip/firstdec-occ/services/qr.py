"""QR code generation using the system libqrencode via ctypes.

No external Python package (qrcode/segno) is required — this binds directly
to libqrencode.so.4, which ships with most Linux distros
(`apt-get install libqrencode4` if it's ever missing), and renders the
resulting module matrix to a PNG with Pillow.
"""
import ctypes
import ctypes.util
import os

from PIL import Image

_libname = ctypes.util.find_library("qrencode") or "libqrencode.so.4"
_lib = ctypes.CDLL(_libname)


class _QRcode(ctypes.Structure):
    _fields_ = [
        ("version", ctypes.c_int),
        ("width", ctypes.c_int),
        ("data", ctypes.POINTER(ctypes.c_ubyte)),
    ]


_lib.QRcode_encodeString8bit.restype = ctypes.POINTER(_QRcode)
_lib.QRcode_encodeString8bit.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
_lib.QRcode_free.argtypes = [ctypes.POINTER(_QRcode)]

QR_ECLEVEL_L, QR_ECLEVEL_M, QR_ECLEVEL_Q, QR_ECLEVEL_H = 0, 1, 2, 3


def generate_qr_image(text, scale=8, quiet_zone=4, level=QR_ECLEVEL_M):
    """Return a Pillow Image ('1' mode, black-on-white) encoding `text`."""
    qr_ptr = _lib.QRcode_encodeString8bit(text.encode("utf-8"), 0, level)
    if not qr_ptr:
        raise RuntimeError("QR encoding failed")
    try:
        qr = qr_ptr.contents
        width = qr.width
        img_size = (width + quiet_zone * 2) * scale
        img = Image.new("1", (img_size, img_size), 1)
        px = img.load()
        for y in range(width):
            row_offset = y * width
            for x in range(width):
                if qr.data[row_offset + x] & 1:
                    x0 = (x + quiet_zone) * scale
                    y0 = (y + quiet_zone) * scale
                    for dy in range(scale):
                        for dx in range(scale):
                            px[x0 + dx, y0 + dy] = 0
        return img
    finally:
        _lib.QRcode_free(qr_ptr)


def save_equipment_qr(equipment_code, base_url, out_dir):
    """Generate and save a QR PNG for one equipment item; returns the file path."""
    os.makedirs(out_dir, exist_ok=True)
    url = f"{base_url.rstrip('/')}/scan/{equipment_code}"
    img = generate_qr_image(url)
    path = os.path.join(out_dir, f"{equipment_code}.png")
    img.save(path)
    return path
