import os
from datetime import datetime
from xml.sax.saxutils import escape as xml_escape

from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.units import mm
from reportlab.lib import colors

from config import DATA_DIR
from db.db import query, execute
from services.pdf_common import (
    styles, draw_page_border, letterhead_banner, section_header, signature_block, kv_table,
    NAVY, LIGHT_GREY, PAGE_SIZE, MARGIN,
)

DEFAULT_VAT_RATE = 7.5  # Nigerian standard VAT rate, editable per invoice

EXPORT_DIR = os.path.join(DATA_DIR, "exports", "invoices")


def next_invoice_number(invoice_type):
    prefix = "FD-INV" if invoice_type == "client" else "FD-VEND"
    year = datetime.now().year
    row = query(
        "SELECT invoice_number FROM invoices WHERE invoice_number LIKE ? ORDER BY id DESC LIMIT 1",
        (f"{prefix}-{year}-%",), one=True,
    )
    seq = 1
    if row:
        try:
            seq = int(row["invoice_number"].split("-")[-1]) + 1
        except ValueError:
            pass
    return f"{prefix}-{year}-{seq:04d}"


def calculate_totals(items, vat_rate=DEFAULT_VAT_RATE):
    subtotal = sum(i["quantity"] * i["unit_price"] for i in items)
    vat_amount = round(subtotal * (vat_rate / 100.0), 2)
    return round(subtotal, 2), vat_amount, round(subtotal + vat_amount, 2)


def create_invoice(project_id, invoice_type, party_name, issue_date, due_date, items, vat_rate=DEFAULT_VAT_RATE,
                    notes=None):
    invoice_number = next_invoice_number(invoice_type)
    subtotal, vat_amount, total = calculate_totals(items, vat_rate)
    invoice_id = execute(
        "INSERT INTO invoices (invoice_number, project_id, invoice_type, party_name, issue_date, due_date, "
        "subtotal, vat_rate, vat_amount, total, status, notes) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?)",
        (invoice_number, project_id, invoice_type, party_name, issue_date, due_date, subtotal, vat_rate,
         vat_amount, total, notes),
    )
    for item in items:
        amount = item["quantity"] * item["unit_price"]
        execute(
            "INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, amount, equipment_id, "
            "document_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (invoice_id, item["description"], item["quantity"], item["unit_price"], amount,
             item.get("equipment_id"), item.get("document_id")),
        )
    return invoice_id


def get_invoice(invoice_id):
    invoice = query("SELECT i.*, p.name AS project_name, p.code AS project_code FROM invoices i "
                     "LEFT JOIN projects p ON p.id = i.project_id WHERE i.id = ?", (invoice_id,), one=True)
    items = query("SELECT * FROM invoice_items WHERE invoice_id = ?", (invoice_id,))
    return invoice, items


def money(v):
    # Standard PDF base fonts (Helvetica) don't carry the ₦ glyph, so PDFs use the
    # NGN currency code; the web UI (templates/*.html) still shows the ₦ symbol.
    return f"NGN {v:,.2f}"


def generate_invoice_pdf(invoice_id):
    invoice, items = get_invoice(invoice_id)
    if invoice is None:
        raise ValueError("Invoice not found")

    os.makedirs(EXPORT_DIR, exist_ok=True)
    path = os.path.join(EXPORT_DIR, f"{invoice['invoice_number']}.pdf")

    doc = SimpleDocTemplate(path, pagesize=PAGE_SIZE, topMargin=22 * mm, bottomMargin=18 * mm,
                             leftMargin=MARGIN, rightMargin=MARGIN, title=invoice["invoice_number"])

    story = []
    title = "TAX INVOICE" if invoice["invoice_type"] == "client" else "VENDOR PAYMENT ADVICE"
    story.append(letterhead_banner(title, [
        f"Invoice No: {invoice['invoice_number']}",
        f"Project: {invoice['project_name'] or '—'} ({invoice['project_code'] or '—'})",
    ]))
    story.append(Spacer(1, 6 * mm))

    bill_label = "Bill To" if invoice["invoice_type"] == "client" else "Pay To"
    story.append(kv_table([
        (bill_label, invoice["party_name"]),
        ("Issue Date", invoice["issue_date"]),
        ("Due Date", invoice["due_date"] or "—"),
        ("Status", invoice["status"].title()),
    ]))
    story.append(Spacer(1, 5 * mm))

    story.append(section_header("Line Items"))
    table_data = [["#", "Description", "Qty", "Unit Price", "Amount"]]
    for idx, item in enumerate(items, start=1):
        table_data.append([
            str(idx),
            Paragraph(xml_escape(item["description"]), styles["FDBody"]),
            f"{item['quantity']:g}",
            money(item["unit_price"]),
            money(item["amount"]),
        ])
    items_table = Table(table_data, colWidths=[9 * mm, 95 * mm, 15 * mm, 27.5 * mm, 27.5 * mm])
    items_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), LIGHT_GREY),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (2, 0), (-1, -1), "RIGHT"),
        ("ALIGN", (0, 0), (0, -1), "CENTER"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(items_table)
    story.append(Spacer(1, 3 * mm))

    totals_data = [
        ["", "Subtotal", money(invoice["subtotal"])],
        ["", f"VAT ({invoice['vat_rate']:g}%)", money(invoice["vat_amount"])],
        ["", "Total Due", money(invoice["total"])],
    ]
    totals_table = Table(totals_data, colWidths=[100 * mm, 37 * mm, 37 * mm])
    totals_table.setStyle(TableStyle([
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("FONTNAME", (1, 2), (-1, 2), "Helvetica-Bold"),
        ("FONTSIZE", (1, 0), (-1, -1), 10),
        ("LINEABOVE", (1, 2), (-1, 2), 1, NAVY),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(totals_table)
    story.append(Spacer(1, 4 * mm))

    if invoice["notes"]:
        story.append(Paragraph(f"<b>Notes:</b> {xml_escape(invoice['notes'])}", styles["FDBody"]))
        story.append(Spacer(1, 4 * mm))

    story.append(Paragraph(
        "VAT charged in accordance with the Value Added Tax Act (Nigeria). Payment due within the terms "
        "stated above to FIRSTDEC LOGISTICS' designated account.", styles["FDSmall"]))
    story.append(Spacer(1, 10 * mm))
    story.append(signature_block(("Prepared By", "Checked By", "Approved By")))

    doc.build(story, onFirstPage=draw_page_border, onLaterPages=draw_page_border)

    execute("UPDATE invoices SET pdf_path = ? WHERE id = ?", (path, invoice_id))
    return path
