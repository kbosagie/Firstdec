"""Auto-computed operations reminders.

Rather than being hand-created, reminders are derived each time
`refresh_reminders()` runs (called from the dashboard and from a manual
"Refresh" button) from the live state of documents and equipment. Each
reminder has a stable `reminder_key` business key so re-running the refresh
upserts instead of duplicating, and a reminder that's no longer applicable
(e.g. the document got signed) is auto-resolved.
"""
from datetime import datetime, timedelta

from db.db import query, execute

CLEANING_STALE_DAYS = 3        # a skip sitting in "cleaning" longer than this gets flagged
ACPML_STALE_HOURS = 48          # equipment sitting at ACPML longer than this gets flagged
RETURN_STALE_DAYS = 5           # equipment "ready_for_collection" longer than this gets flagged
CERT_EXPIRY_WARNING_DAYS = 30


def _upsert(key, rtype, project_id, equipment_id, document_id, message, severity, due_date=None):
    existing = query("SELECT id FROM reminders WHERE reminder_key = ?", (key,), one=True)
    if existing:
        execute(
            "UPDATE reminders SET message=?, severity=?, due_date=?, status='open', reminder_type=? "
            "WHERE id=?",
            (message, severity, due_date, rtype, existing["id"]),
        )
    else:
        execute(
            "INSERT INTO reminders (reminder_key, reminder_type, project_id, equipment_id, document_id, "
            "message, severity, due_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'open')",
            (key, rtype, project_id, equipment_id, document_id, message, severity, due_date),
        )


def refresh_reminders():
    now = datetime.now()
    active_keys = set()

    # 1. Unsigned EDNs / CWCTNs / other pending-signature documents.
    pending_docs = query(
        "SELECT d.*, p.name AS project_name FROM documents d LEFT JOIN projects p ON p.id = d.project_id "
        "WHERE d.status = 'pending_signature'"
    )
    for doc in pending_docs:
        key = f"unsigned_doc_{doc['id']}"
        active_keys.add(key)
        due = doc["due_date"]
        overdue = bool(due) and due < now.strftime("%Y-%m-%d")
        rtype = {
            "EDN": "unsigned_edn",
            "CWCTN": "unsigned_cwctn",
            "WASTE_DISPOSAL_CERT": "outstanding_disposal_cert",
            "ERN": "overdue_return",
        }.get(doc["doc_type"], "missing_document")
        label = doc["doc_type"].replace("_", " ")
        message = f"{label} {doc['doc_number'] or '(no number)'} awaiting {doc['counterparty'] or 'signature'}"
        if doc["project_name"]:
            message += f" — {doc['project_name']}"
        _upsert(key, rtype, doc["project_id"], None, doc["id"], message,
                "red" if overdue else "orange", due)

    # 2. Skips sitting in "cleaning" too long.
    stale_cutoff = (now - timedelta(days=CLEANING_STALE_DAYS)).strftime("%Y-%m-%d %H:%M:%S")
    cleaning = query(
        "SELECT e.*, "
        "(SELECT MAX(m.occurred_at) FROM movements m WHERE m.equipment_id = e.id AND m.new_status='cleaning') "
        "AS since "
        "FROM equipment e WHERE e.current_status = 'cleaning'"
    )
    for eq in cleaning:
        key = f"cleaning_due_{eq['id']}"
        since = eq["since"] or eq["created_at"]
        if since and since < stale_cutoff:
            active_keys.add(key)
            _upsert(key, "cleaning_due", eq["current_project_id"], eq["id"], None,
                    f"{eq['equipment_id']} has been awaiting cleaning at {eq['current_location']} "
                    f"since {since[:10]}", "orange")

    # 3. Equipment sitting at ACPML beyond the SLA window.
    acpml_cutoff = (now - timedelta(hours=ACPML_STALE_HOURS)).strftime("%Y-%m-%d %H:%M:%S")
    at_acpml = query(
        "SELECT e.*, "
        "(SELECT MAX(m.occurred_at) FROM movements m WHERE m.equipment_id = e.id AND m.to_location='ACPML') "
        "AS since "
        "FROM equipment e WHERE e.current_status = 'at_acpml'"
    )
    for eq in at_acpml:
        since = eq["since"] or eq["created_at"]
        if since and since < acpml_cutoff:
            key = f"acpml_overdue_{eq['id']}"
            active_keys.add(key)
            _upsert(key, "cleaning_due", eq["current_project_id"], eq["id"], None,
                    f"{eq['equipment_id']} has been at ACPML since {since[:10]} — over the "
                    f"{ACPML_STALE_HOURS}h SLA", "orange")

    # 4. Equipment ready for collection but not yet returned.
    ready_cutoff = (now - timedelta(days=RETURN_STALE_DAYS)).strftime("%Y-%m-%d %H:%M:%S")
    ready = query(
        "SELECT e.*, "
        "(SELECT MAX(m.occurred_at) FROM movements m WHERE m.equipment_id = e.id "
        " AND m.new_status='ready_for_collection') AS since "
        "FROM equipment e WHERE e.current_status = 'ready_for_collection'"
    )
    for eq in ready:
        since = eq["since"] or eq["created_at"]
        key = f"return_outstanding_{eq['id']}"
        severity = "red" if (since and since < ready_cutoff) else "orange"
        active_keys.add(key)
        _upsert(key, "overdue_return", eq["current_project_id"], eq["id"], None,
                f"{eq['equipment_id']} ready for collection from {eq['current_location']} "
                f"since {since[:10] if since else 'unknown'} — Equipment Return Note outstanding",
                severity)

    # 5. Certification expiring soon.
    cert_cutoff = (now + timedelta(days=CERT_EXPIRY_WARNING_DAYS)).strftime("%Y-%m-%d")
    expiring = query(
        "SELECT * FROM equipment WHERE certification_expiry IS NOT NULL AND certification_expiry != '' "
        "AND certification_expiry <= ?", (cert_cutoff,)
    )
    for eq in expiring:
        key = f"cert_expiring_{eq['id']}"
        active_keys.add(key)
        expired = eq["certification_expiry"] < now.strftime("%Y-%m-%d")
        _upsert(key, "cert_expiring", eq["current_project_id"], eq["id"], None,
                f"{eq['equipment_id']} certification "
                f"{'expired' if expired else 'expires'} {eq['certification_expiry']}",
                "red" if expired else "orange")

    # Auto-resolve reminders that are still 'open' but weren't touched this pass.
    open_reminders = query("SELECT id, reminder_key FROM reminders WHERE status = 'open'")
    for r in open_reminders:
        if r["reminder_key"] not in active_keys:
            execute("UPDATE reminders SET status='resolved', resolved_at=datetime('now') WHERE id=?",
                     (r["id"],))


def get_open_reminders(project_id=None):
    if project_id:
        return query(
            "SELECT r.*, p.name AS project_name, e.equipment_id AS equipment_code "
            "FROM reminders r LEFT JOIN projects p ON p.id=r.project_id "
            "LEFT JOIN equipment e ON e.id=r.equipment_id "
            "WHERE r.status='open' AND r.project_id=? "
            "ORDER BY CASE r.severity WHEN 'red' THEN 0 WHEN 'orange' THEN 1 ELSE 2 END, r.due_date",
            (project_id,),
        )
    return query(
        "SELECT r.*, p.name AS project_name, e.equipment_id AS equipment_code "
        "FROM reminders r LEFT JOIN projects p ON p.id=r.project_id "
        "LEFT JOIN equipment e ON e.id=r.equipment_id "
        "WHERE r.status='open' "
        "ORDER BY CASE r.severity WHEN 'red' THEN 0 WHEN 'orange' THEN 1 ELSE 2 END, r.due_date"
    )


def resolve_reminder(reminder_id):
    execute("UPDATE reminders SET status='resolved', resolved_at=datetime('now') WHERE id=?", (reminder_id,))
