"""Shared ReportLab building blocks for FIRSTDEC documents: navy banded
section headers, a thick outer border on every page, and a three-column
signature block — the house letterhead style used for FirstDec documents.
"""
from xml.sax.saxutils import escape as xml_escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

NAVY = colors.HexColor("#0B2545")
GOLD = colors.HexColor("#C8A24A")
LIGHT_GREY = colors.HexColor("#F2F4F7")
BORDER_WIDTH = 2.2

PAGE_SIZE = A4
MARGIN = 16 * mm

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="FDTitle", fontName="Helvetica-Bold", fontSize=16, textColor=colors.white,
                          leading=20))
styles.add(ParagraphStyle(name="FDSubtitle", fontName="Helvetica", fontSize=9.5, textColor=colors.white,
                          leading=12))
styles.add(ParagraphStyle(name="FDSectionHeader", fontName="Helvetica-Bold", fontSize=10.5,
                          textColor=colors.white, leftIndent=4))
styles.add(ParagraphStyle(name="FDBody", fontName="Helvetica", fontSize=9.5, leading=13))
styles.add(ParagraphStyle(name="FDBodyBold", fontName="Helvetica-Bold", fontSize=9.5, leading=13))
styles.add(ParagraphStyle(name="FDSmall", fontName="Helvetica", fontSize=8, leading=10, textColor=colors.grey))
styles.add(ParagraphStyle(name="FDSigLabel", fontName="Helvetica-Bold", fontSize=8.5, alignment=TA_CENTER))
styles.add(ParagraphStyle(name="FDSigLine", fontName="Helvetica", fontSize=8, alignment=TA_CENTER,
                          textColor=colors.grey))


def draw_page_border(canvas_obj, doc):
    canvas_obj.saveState()
    canvas_obj.setStrokeColor(NAVY)
    canvas_obj.setLineWidth(BORDER_WIDTH)
    inset = 8 * mm
    canvas_obj.rect(inset, inset, PAGE_SIZE[0] - 2 * inset, PAGE_SIZE[1] - 2 * inset)
    canvas_obj.setStrokeColor(GOLD)
    canvas_obj.setLineWidth(0.8)
    canvas_obj.rect(inset + 2, inset + 2, PAGE_SIZE[0] - 2 * inset - 4, PAGE_SIZE[1] - 2 * inset - 4)
    canvas_obj.setFont("Helvetica", 7)
    canvas_obj.setFillColor(colors.grey)
    canvas_obj.drawString(inset + 4, inset - 6 + 4, "FIRSTDEC LOGISTICS — Operations Control Centre")
    canvas_obj.drawRightString(PAGE_SIZE[0] - inset - 4, inset - 6 + 4, f"Page {doc.page}")
    canvas_obj.restoreState()


def letterhead_banner(title, subtitle_lines):
    """Navy banner Table flowable used at the top of every FirstDec document."""
    sub = "<br/>".join(xml_escape(line) for line in subtitle_lines)
    data = [[
        Paragraph("FIRSTDEC LOGISTICS", styles["FDTitle"]),
        Paragraph(f"<b>{xml_escape(title)}</b><br/>{sub}", styles["FDSubtitle"]),
    ]]
    t = Table(data, colWidths=[90 * mm, 84 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), NAVY),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("LEFTPADDING", (0, 0), (0, 0), 10),
        ("RIGHTPADDING", (1, 0), (1, 0), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LINEBELOW", (0, 0), (-1, -1), 2, GOLD),
    ]))
    return t


def section_header(text):
    t = Table([[Paragraph(xml_escape(text.upper()), styles["FDSectionHeader"])]], colWidths=[174 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), NAVY),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
    ]))
    return t


def signature_block(labels=("Prepared By", "Checked By", "Approved By")):
    cells = []
    for label in labels:
        cells.append(Paragraph(
            f"_________________________<br/>"
            f"<font size=8.5><b>{label}</b></font><br/>"
            f"<font size=7.5 color='grey'>Name / Signature / Date</font>",
            styles["FDSigLabel"],
        ))
    t = Table([cells], colWidths=[58 * mm] * 3)
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 18),
        ("BOX", (0, 0), (0, 0), 0.75, colors.HexColor("#CCCCCC")),
        ("LINEAFTER", (0, 0), (0, 0), 0.75, colors.HexColor("#DDDDDD")),
        ("LINEAFTER", (1, 0), (1, 0), 0.75, colors.HexColor("#DDDDDD")),
    ]))
    return t


def kv_table(pairs, col_widths=(40 * mm, 47 * mm, 40 * mm, 47 * mm)):
    """A neat 2x2-per-row label/value grid for header metadata."""
    rows = []
    for i in range(0, len(pairs), 2):
        row = []
        for label, value in pairs[i:i + 2]:
            row.append(Paragraph(f"<font color='grey' size=8>{xml_escape(str(label))}</font>", styles["FDBody"]))
            row.append(Paragraph(f"<b>{xml_escape(str(value))}</b>", styles["FDBody"]))
        if len(row) < 4:
            row.extend([""] * (4 - len(row)))
        rows.append(row)
    t = Table(rows, colWidths=list(col_widths))
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    return t
