"""Small shared text-formatting helper so FIRSTDEC's document/equipment
acronyms (EDN, CWCTN, ACPML, CCU, IBC, ...) don't get mangled into
half-capitalised words like "Cwctn" or "Ccu" by a naive str.title()."""

ACRONYMS = {"edn", "ern", "cwctn", "acpml", "ibc", "ccu", "vat", "wdc", "psv", "mbc", "qr"}


def friendly_label(text):
    if not text:
        return text
    words = str(text).replace("_", " ").split(" ")
    return " ".join(w.upper() if w.lower() in ACRONYMS else w.capitalize() for w in words)
