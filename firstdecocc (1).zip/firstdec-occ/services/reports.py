import os
from datetime import datetime, timedelta
from xml.sax.saxutils import escape as xml_escape

from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.units import mm
from reportlab.lib import colors

from config import DATA_DIR
from db.db import query
from services.pdf_common import (
    styles, draw_page_border, letterhead_banner, section_header, kv_table, PAGE_SIZE, MARGIN, LIGHT_GREY, NAVY,
)

EXPORT_DIR = os.path.join(DATA_DIR, "exports", "reports")

PERIOD_DAYS = {"daily": 1, "weekly": 7, "monthly": 30, "final": None}


def _period_bounds(period):
    end = datetime.now()
    days = PERIOD_DAYS.get(period, 7)
    start = None if days is None else end - timedelta(days=days)
    return start, end


def build_report(period, project_id=None):
    start, end = _period_bounds(period)
    start_str = start.strftime("%Y-%m-%d %H:%M:%S") if start else "1900-01-01"

    project = None
    if project_id:
        project = query("SELECT * FROM projects WHERE id = ?", (project_id,), one=True)

    proj_filter = " AND project_id = ?" if project_id else ""
    proj_params = (project_id,) if project_id else ()

    movements = query(
        "SELECT m.*, e.equipment_id AS equipment_code FROM movements m "
        "JOIN equipment e ON e.id = m.equipment_id "
        "WHERE m.occurred_at >= ?" + proj_filter.replace("project_id", "m.project_id") +
        " ORDER BY m.occurred_at DESC",
        (start_str,) + proj_params,
    )

    docs_outstanding = query(
        "SELECT * FROM documents WHERE status != 'completed'" + proj_filter, proj_params
    )
    docs_completed_period = query(
        "SELECT * FROM documents WHERE status = 'completed' AND signed_date >= ?" + proj_filter,
        (start_str[:10],) + proj_params,
    )

    waste_filter = " AND project_id = ?" if project_id else ""
    waste_rows = query(
        "SELECT waste_type, COALESCE(SUM(net_weight_kg),0) kg, COUNT(*) n FROM waste_transactions "
        "WHERE (processing_date >= ? OR processing_date IS NULL)" + waste_filter + " GROUP BY waste_type",
        (start_str[:10],) + ((project_id,) if project_id else ()),
    )

    equip_filter = " WHERE current_project_id = ?" if project_id else ""
    equipment_counts = query(
        "SELECT current_status, COUNT(*) c FROM equipment" + equip_filter + " GROUP BY current_status",
        (project_id,) if project_id else (),
    )

    invoice_filter = " AND project_id = ?" if project_id else ""
    invoices = query(
        "SELECT * FROM invoices WHERE issue_date >= ?" + invoice_filter, (start_str[:10],) + ((project_id,) if project_id else ()),
    )

    return {
        "period": period,
        "project": project,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "range_label": ("All time" if start is None else f"{start.strftime('%d %b %Y')} – {end.strftime('%d %b %Y')}"),
        "movements": movements,
        "docs_outstanding": docs_outstanding,
        "docs_completed_period": docs_completed_period,
        "waste_rows": waste_rows,
        "equipment_counts": {r["current_status"]: r["c"] for r in equipment_counts},
        "invoices": invoices,
        "invoice_total": sum(i["total"] for i in invoices),
    }


def generate_report_pdf(report):
    os.makedirs(EXPORT_DIR, exist_ok=True)
    project = report["project"]
    scope = project["code"] if project else "ALL-PROJECTS"
    filename = f"{report['period'].upper()}-{scope}-{datetime.now().strftime('%Y%m%d%H%M')}.pdf"
    path = os.path.join(EXPORT_DIR, filename)

    doc = SimpleDocTemplate(path, pagesize=PAGE_SIZE, topMargin=22 * mm, bottomMargin=18 * mm,
                             leftMargin=MARGIN, rightMargin=MARGIN, title=filename)
    story = []
    title = f"{report['period'].title()} Operations Report"
    story.append(letterhead_banner(title, [
        f"Scope: {project['name'] if project else 'All Active Projects'}",
        f"Period: {report['range_label']}  •  Generated {report['generated_at']}",
    ]))
    story.append(Spacer(1, 6 * mm))

    story.append(section_header("Equipment Status Summary"))
    ec = report["equipment_counts"]
    labels = [("Offshore", "offshore"), ("At Aveon", "at_aveon"), ("At ACPML", "at_acpml"),
              ("Cleaning", "cleaning"), ("Ready for Collection", "ready_for_collection"),
              ("Returned", "returned")]
    row1 = [l for l, _ in labels]
    row2 = [str(ec.get(k, 0)) for _, k in labels]
    t = Table([row1, row2], colWidths=[29 * mm] * 6)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), LIGHT_GREY),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTNAME", (0, 1), (-1, 1), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(t)
    story.append(Spacer(1, 5 * mm))

    story.append(section_header(f"Equipment Movements ({len(report['movements'])})"))
    if report["movements"]:
        mv_data = [["Date", "Equipment", "Type", "From", "To", "Notes"]]
        for m in report["movements"][:40]:
            mv_data.append([
                m["occurred_at"][:10], m["equipment_code"], m["movement_type"].replace("_", " "),
                m["from_location"] or "—", m["to_location"],
                Paragraph(xml_escape((m["notes"] or "")[:80]), styles["FDSmall"]),
            ])
        mv_table = Table(mv_data, colWidths=[20 * mm, 24 * mm, 24 * mm, 24 * mm, 24 * mm, 58 * mm])
        mv_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), LIGHT_GREY),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 7.5),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#DDDDDD")),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(mv_table)
    else:
        story.append(Paragraph("No movements recorded in this period.", styles["FDBody"]))
    story.append(Spacer(1, 5 * mm))

    story.append(section_header(f"Outstanding Documents ({len(report['docs_outstanding'])})"))
    if report["docs_outstanding"]:
        doc_data = [["Type", "Number", "Counterparty", "Status", "Due"]]
        for d in report["docs_outstanding"][:30]:
            doc_data.append([
                Paragraph(xml_escape(d["doc_type"].replace("_", " ")), styles["FDSmall"]),
                Paragraph(xml_escape(d["doc_number"] or "—"), styles["FDSmall"]),
                Paragraph(xml_escape(d["counterparty"] or "—"), styles["FDSmall"]),
                Paragraph(xml_escape(d["status"].replace("_", " ").title()), styles["FDSmall"]),
                d["due_date"] or "—",
            ])
        dtab = Table(doc_data, colWidths=[30 * mm, 32 * mm, 34 * mm, 30 * mm, 28 * mm])
        dtab.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), LIGHT_GREY),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#DDDDDD")),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(dtab)
    else:
        story.append(Paragraph("No outstanding documents.", styles["FDBody"]))
    story.append(Spacer(1, 5 * mm))

    story.append(section_header("Waste Processed"))
    if report["waste_rows"]:
        w_data = [["Waste Type", "Tonnes", "Transactions"]]
        for w in report["waste_rows"]:
            w_data.append([w["waste_type"], f"{(w['kg'] or 0)/1000:,.2f}", str(w["n"])])
        wtab = Table(w_data, colWidths=[58 * mm, 58 * mm, 58 * mm])
        wtab.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), LIGHT_GREY),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8.5),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#DDDDDD")),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(wtab)
    else:
        story.append(Paragraph("No waste transactions recorded.", styles["FDBody"]))
    story.append(Spacer(1, 5 * mm))

    story.append(section_header("Invoicing"))
    story.append(Paragraph(
        f"{len(report['invoices'])} invoice(s) issued this period, totalling "
        f"NGN {report['invoice_total']:,.2f} (VAT-inclusive).", styles["FDBody"]))

    doc.build(story, onFirstPage=draw_page_border, onLaterPages=draw_page_border)
    return path
