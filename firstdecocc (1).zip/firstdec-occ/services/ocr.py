"""Document scanning / OCR extraction.

Accepts an uploaded image or PDF, gets raw text out of it (Tesseract for
images and scanned PDFs, direct text extraction for text-layer PDFs), then
pulls out the fields operations cares about with a set of regexes tuned to
FIRSTDEC's document numbering (EDN/ERN/CWCTN/waybill/manifest/weight-ticket
prefixes) and equipment ID formats (e.g. AIMM01WS, CCU-2201, TANK-3301).

This is deliberately regex/heuristic rather than a trained model — it needs
no external API key or network access, and the extracted fields are always
shown to the user to confirm/correct before saving (see routes/documents.py).
"""
import os
import re
from datetime import datetime

import pytesseract
from PIL import Image

try:
    import pdfplumber
except ImportError:  # pragma: no cover
    pdfplumber = None

try:
    from pdf2image import convert_from_path
except ImportError:  # pragma: no cover
    convert_from_path = None


DOC_NUMBER_PATTERNS = [
    (r"\bEDN[-\s]?(\d{3,6})\b", "EDN"),
    (r"\bERN[-\s]?(\d{3,6})\b", "ERN"),
    (r"\bCWCTN[-\s]?(\d{3,6})\b", "CWCTN"),
    (r"\bWDC[-\s]?(\d{3,6})\b", "WASTE_DISPOSAL_CERT"),
    (r"\bWB[-\s]?(\d{3,6})\b", "WAYBILL"),
    (r"\bWT[-\s]?(\d{3,6})\b", "WEIGHT_TICKET"),
    (r"\bPSV[-\s]?(\d{3,6})\b", "MANIFEST"),
    (r"\bMANIFEST[-\s#:]*([A-Z0-9-]{3,12})\b", "MANIFEST"),
]

EQUIPMENT_ID_RE = re.compile(
    r"\b([A-Z]{2,6}[-]?\d{2,4}[A-Z]{0,3})\b"
)

DATE_PATTERNS = [
    r"\b\d{4}-\d{2}-\d{2}\b",
    r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b",
    r"\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}\b",
]

WEIGHT_RE = re.compile(
    r"(\d[\d,]*(?:\.\d+)?)\s*(kg|kgs|tonnes?|tons?|mt)\b", re.IGNORECASE
)

QTY_RE = re.compile(r"\b(?:qty|quantity)[:\s]*(\d+)\b", re.IGNORECASE)


def extract_text(file_path):
    """Return raw text from an uploaded document (image or PDF)."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext in (".png", ".jpg", ".jpeg", ".tiff", ".bmp"):
        return pytesseract.image_to_string(Image.open(file_path))

    if ext == ".pdf":
        text = ""
        if pdfplumber is not None:
            try:
                with pdfplumber.open(file_path) as pdf:
                    text = "\n".join(page.extract_text() or "" for page in pdf.pages)
            except Exception:
                text = ""
        if len(text.strip()) < 20 and convert_from_path is not None:
            # Likely a scanned PDF with no text layer — fall back to OCR.
            try:
                pages = convert_from_path(file_path, dpi=200)
                text = "\n".join(pytesseract.image_to_string(p) for p in pages)
            except Exception:
                pass
        return text

    # Unknown type: try reading as text.
    try:
        with open(file_path, "r", errors="ignore") as f:
            return f.read()
    except Exception:
        return ""


def guess_doc_type_and_number(text):
    for pattern, doc_type in DOC_NUMBER_PATTERNS:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            number = m.group(0).upper().replace(" ", "-")
            return doc_type, number
    return None, None


def extract_equipment_ids(text):
    candidates = set(EQUIPMENT_ID_RE.findall(text.upper()))
    # Filter out obvious false positives (pure doc-number prefixes already matched above).
    noise = {"EDN", "ERN", "CWCTN", "WDC", "WB", "WT", "PSV"}
    return sorted(c for c in candidates if c not in noise and len(c) >= 5)


def extract_dates(text):
    found = []
    for pattern in DATE_PATTERNS:
        found.extend(re.findall(pattern, text, re.IGNORECASE))
    return found


def extract_weights(text):
    return [{"value": float(v.replace(",", "")), "unit": u.lower()} for v, u in WEIGHT_RE.findall(text)]


def extract_quantity(text):
    m = QTY_RE.search(text)
    return int(m.group(1)) if m else None


def extract_fields(file_path):
    """Full pipeline: OCR/text-extract then field extraction. Returns a dict
    ready to pre-fill the document-upload confirmation form."""
    text = extract_text(file_path)
    doc_type, doc_number = guess_doc_type_and_number(text)
    return {
        "raw_text_preview": text.strip()[:2000],
        "doc_type": doc_type,
        "doc_number": doc_number,
        "equipment_ids": extract_equipment_ids(text),
        "dates": extract_dates(text),
        "weights": extract_weights(text),
        "quantity": extract_quantity(text),
    }
