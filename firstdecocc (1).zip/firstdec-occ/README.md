# FIRSTDEC Operations Control Centre

A cloud-ready equipment, logistics and waste-management platform for FIRSTDEC LOGISTICS,
built around the brief's core principle: **everything revolves around a Project ID and an
Equipment ID.** Open any skip, tank, IBC, CCU or basket and see its complete history —
every movement, document, waste transaction and invoice tied to it.

This is the **Phase 1 Operations Control Centre** plus the automation pieces you asked to
bring forward: VAT invoicing, document scanning/OCR, and a natural-language operations
assistant. It runs with **zero external services or API keys** — no AWS/Azure account,
no WhatsApp Business API, no LLM subscription required to try it today. See
[What's not in this build yet](#whats-not-in-this-build-yet) for the honest list of what
Phase 2/3 items (WhatsApp, live GPS, client/vendor/waste-contractor portals) still need.

## What's included

| Module | What it does |
|---|---|
| **Equipment Register** | Full profile per item (owner, serial, certification, condition, location, status) for skips, tanks, IBCs, CCUs and baskets. |
| **QR Tracking** | Every equipment item gets a generated QR code linking to a mobile-friendly scan page — scanning it lets a driver log a location/status update and a photo, no login required. |
| **Logistics / Movements** | Log the Libroid → Aveon → Offshore → Aveon → ACPML → cleaning → return cycle; each entry updates the equipment's current status automatically. |
| **Document Control** | EDNs, ERNs, CWCTNs, waste disposal certificates, waybills, manifests and weight tickets — each one attached to a project and to specific equipment. |
| **Document Scanning / OCR** | Upload a PDF or photo of a document; it's read with Tesseract OCR (and direct text extraction for text-layer PDFs), and document number, equipment IDs, dates and weights are pulled out automatically for you to confirm before saving. |
| **Operations Reminders** | Auto-computed (not hand-entered) from live document/equipment state: unsigned EDNs/CWCTNs, outstanding disposal certificates, skips overdue for cleaning, equipment sitting at ACPML past a 48-hour SLA, overdue returns, expiring certifications. |
| **Invoicing** | Client and vendor invoices with Nigerian VAT (7.5% default, editable per invoice) calculated automatically, exported as a bordered, letterhead-styled PDF. |
| **Project Reporting** | Daily / weekly / monthly / final reports per project or across all projects — movements, outstanding documents, waste tonnage, invoicing — as both a web view and a downloadable PDF. |
| **AI Operations Assistant** | A query box that answers straight from the database — "Which skips are still offshore?", "Show CWCTNs awaiting signature", "Which equipment has been at ACPML more than 48 hours?", and more. |
| **Dashboard** | The live operations-room view from the brief: active projects, equipment deployed/offshore/at Aveon/at ACPML/ready for collection/returned, and colour-coded outstanding actions. |

## Quick start

Requires Python 3.10+ and three small system packages most Linux servers already have
(Tesseract for OCR, Poppler for PDF rendering, libqrencode for QR codes):

```bash
# Ubuntu/Debian
sudo apt-get install -y tesseract-ocr poppler-utils libqrencode4

pip install -r requirements.txt
python3 app.py
```

Open **http://localhost:5000** — it's pre-seeded with a realistic demo dataset (the
MB&C Bonga project from the brief, worked all the way through: EDN → offshore →
backload → ACPML → CWCTN → weight ticket → disposal certificate → cleaning →
Equipment Return Note → vendor/client invoices).

**Login:** `kbosagie@gmail.com` / `firstdec2026` (change this — see
[Before you put this in front of real users](#before-you-put-this-in-front-of-real-users)).

To wipe and reseed the demo data at any point:

```bash
python3 -m db.seed
```

## Deploying to the cloud (so your team can reach it, not just your own computer)

The project includes a `Dockerfile` that bundles everything the app needs — Python,
Tesseract, Poppler and libqrencode — so a cloud host doesn't need any manual system
setup. The simplest route, with no command line required on your side:

1. **Put the code on GitHub.** Go to [github.com](https://github.com), create a free
   account if you don't have one, click **New repository** (make it private), then on
   the repository page use **Add file → Upload files** and drag in the whole unzipped
   `firstdec-occ` folder. Commit it.
2. **Create a Render account** at [render.com](https://render.com) (you can sign up
   with your GitHub login). Click **New → Web Service**, connect the GitHub repo you
   just created, and click **Create Web Service**. Render finds the `Dockerfile`
   automatically and builds and deploys it — no configuration needed.
3. **Add a persistent disk** (Render dashboard → your service → **Disks** → **Add
   Disk**), mount path `/var/data`, 1 GB is plenty. Then add an environment variable
   (service → **Environment**): `FIRSTDEC_DATA_DIR` = `/var/data`. This keeps your
   equipment records, documents and invoices safe across restarts and redeploys —
   without it, a free/redeployed service can lose its data.
4. **Set a real secret key** — add another environment variable: `SECRET_KEY` = any
   long random string (this signs login sessions; don't leave it as the default).
5. Wait for the build to finish (a few minutes the first time), then open the `.onrender.com`
   URL Render gives you. First boot seeds the same MB&C Bonga demo data automatically
   (login `kbosagie@gmail.com` / `firstdec2026`) — change the password before real use.

Render's free tier works for trying it out (it sleeps after inactivity, so the first
open after a quiet spell takes ~30 seconds to wake up); their cheapest paid tier
(~$7/month) keeps it always-on, which you'll want once the team relies on it daily.
Railway.app and Fly.io work the same way (connect a repo or point at the Dockerfile) if
you'd rather compare — the Dockerfile is what makes any of them "just work."

Once real operational data is in place, start a *fresh* deploy from an empty database
(rather than the demo dataset) by adding one more environment variable before first
boot: `FIRSTDEC_SKIP_SEED` = `1`.

## How it's built, and why

| Concern | Choice | Why |
|---|---|---|
| Backend | Flask (Python) | No build step, one process, easy to read and extend. |
| Database | SQLite (`instance/firstdec.db`) | Zero setup for a Phase 1 pilot. The schema (`db/schema.sql`) is plain SQL — moving to PostgreSQL later is a matter of swapping `db/db.py`'s connection layer, not rewriting the app. |
| OCR | Tesseract + regex field extraction (`services/ocr.py`) | Runs entirely locally, no per-document cloud API cost. Extracted fields are always shown to a human to confirm before saving — it's a time-saver, not an autonomous data-entry system. |
| QR codes | Direct binding to `libqrencode` (`services/qr.py`) | No external QR library or network call needed. |
| PDF documents | ReportLab, hand-built to the FirstDec letterhead style (`services/pdf_common.py`) — navy banded section headers, thick outer border, three-column signature blocks. | Matches your existing document standard. |
| AI Assistant | Rule-based query matching against the live database (`services/assistant.py`) | Answers instantly, needs no API key, and every answer is traceable to a real query. `answer_query()` is the one function to swap in an LLM later if you want free-form phrasing — everything else (routes, chat UI) stays as-is. |

## What's not in this build yet

Being direct about the gap between this and the full vision in your brief:

- **WhatsApp Business API integration** (drivers texting updates) — needs a Meta/WhatsApp
  Business account and webhook hosting. The equivalent workflow exists today as the QR
  **scan page** (`/scan/<equipment_id>`), which any phone browser can open with no app
  install.
- **Live GPS truck tracking** — needs a telematics/GPS provider and device hardware on the
  trucks; out of scope for a software-only build.
- **Client / Vendor / Waste-Contractor portals** — today MB&C, Libroid and ACPML would use
  the same Operations login. Separate, restricted-view logins for each party are a
  natural Phase 2 addition (the `users.role` column is already there to build on).
- **Email integration** (auto-attaching incoming emails to a project) — needs a mailbox
  connector; not wired up.
- **Production authentication** (Microsoft Azure AD / Auth0 single sign-on) — this build
  uses simple email+password login (Werkzeug-hashed) so it works out of the box.
- **A free-form LLM-backed assistant** — the current assistant is intentionally rule-based
  (no API key needed); swapping in a real LLM is a one-function change, noted above.

## Before you put this in front of real users

1. **Change the login.** Edit `db/seed.py`'s `admin_password`, or add a proper user-management
   screen — there isn't one yet, so add users directly in SQLite for now.
2. **Set a real `SECRET_KEY`** environment variable (used to sign login sessions).
3. **The `/scan/<equipment_id>` QR page is deliberately public** (no login) so field drivers
   can use it without an account. Anyone with a QR code's URL can log an update. For a
   pilot on a private network this is a reasonable trade-off; before wider rollout, add a
   short PIN or token to the scan URL.
4. **Run behind a real WSGI server**, e.g.:
   ```bash
   gunicorn -w 4 -b 0.0.0.0:8000 app:app
   ```
   and put nginx (or similar) in front of it with HTTPS. If you deployed with the
   `Dockerfile` (see [Deploying to the cloud](#deploying-to-the-cloud-so-your-team-can-reach-it-not-just-your-own-computer)),
   this is already handled — gunicorn is what the container runs, and Render/Railway/
   Fly.io all provide HTTPS automatically.
5. **Set `FIRSTDEC_DATA_DIR`** to a persistent-disk path if you're on a host with an
   ephemeral filesystem (see the cloud deployment section) — otherwise the database
   and uploaded documents disappear on every restart or redeploy.
6. **Move to PostgreSQL** once more than a handful of people are using it concurrently —
   SQLite is fine for a pilot but not for many simultaneous writers.

## Project layout

```
app.py                  Flask app factory + route registration
config.py                Where persistent data lives (FIRSTDEC_DATA_DIR override for cloud hosts)
Dockerfile               Container image for cloud deployment (bundles Tesseract/Poppler/libqrencode)
db/schema.sql            Full database schema (projects, equipment, movements, documents,
                          waste transactions, invoices, reminders, ...)
db/seed.py                Demo data — the MB&C Bonga worked example from the brief
db/db.py                  Thin SQLite connection layer (swap this to move to Postgres)
services/                 Business logic: OCR, QR codes, reminders, invoicing, reports,
                          the AI assistant, PDF letterhead helpers
routes/                   Flask blueprints — one per module (equipment, documents, ...)
templates/                Jinja2 HTML templates (navy/gold house style, no CDN dependency)
static/css/style.css      The entire stylesheet — self-contained, no external fonts/CDN
uploads/                  Uploaded document files land here
exports/                  Generated invoice/report PDFs land here
```
