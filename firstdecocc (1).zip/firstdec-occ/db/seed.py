"""Seeds demo data: the MB&C Bonga project example from the FIRSTDEC brief,
plus a couple of extra projects/equipment so the dashboard and AI assistant
have something realistic to answer questions about.

Run with:  python3 -m db.seed
"""
import json
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash

from db.db import init_db, execute, query


def d(days_ago):
    return (datetime.now() - timedelta(days=days_ago)).strftime("%Y-%m-%d")


def dt(days_ago, hours_ago=0):
    return (datetime.now() - timedelta(days=days_ago, hours=hours_ago)).strftime("%Y-%m-%d %H:%M:%S")


def run(admin_email="kbosagie@gmail.com", admin_name="Kazeem Bello Osagie", admin_password="firstdec2026"):
    init_db(reset=True)

    execute(
        "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)",
        (admin_name, admin_email, generate_password_hash(admin_password), "admin"),
    )

    # --- Projects -----------------------------------------------------
    p1 = execute(
        "INSERT INTO projects (code, name, client_name, status, start_date, description) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("MBC-BONGA", "MB&C Bonga Project", "MB&C", "active", d(21),
         "Offshore skip/CCU logistics, waste handling and disposal for the Bonga field programme."),
    )
    p2 = execute(
        "INSERT INTO projects (code, name, client_name, status, start_date, description) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        ("BG-BLUEGRETHA", "Blue Gretha Manifest Programme", "Blue Gretha", "active", d(10),
         "Waste manifest reconciliation and skip cycling for the Blue Gretha vessel programme."),
    )
    p3 = execute(
        "INSERT INTO projects (code, name, client_name, status, start_date, end_date, description) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        ("SEPLAT-OML40", "Seplat OML40 Support", "Seplat", "completed", d(90), d(30),
         "Completed tank and IBC support programme."),
    )

    # --- Equipment ------------------------------------------------------
    equipment = [
        # equipment_id, type, owner, serial, cert_expiry, condition, location, status, project
        ("AIMM01WS", "skip", "Libroid", "LB-SK-1001", d(-200), "good", "Offshore", "offshore", p1),
        ("AIMM02WS", "skip", "Libroid", "LB-SK-1002", d(-200), "good", "ACPML", "at_acpml", p1),
        ("AIMM03WS", "skip", "Libroid", "LB-SK-1003", d(-180), "good", "ACPML", "cleaning", p1),
        ("AIMM04WS", "skip", "Libroid", "LB-SK-1004", d(-180), "good", "Aveon", "at_aveon", p1),
        ("AIMM05WS", "skip", "Libroid", "LB-SK-1005", d(-150), "damaged", "ACPML", "at_acpml", p1),
        ("AIMM06WS", "skip", "Libroid", "LB-SK-1006", d(-150), "good", "Libroid", "ready_for_collection", None),
        ("AIMM07WS", "skip", "Libroid", "LB-SK-1007", d(-150), "good", "Libroid", "returned", None),
        ("CCU-2201", "ccu", "Aveon", "AV-CCU-2201", d(-300), "good", "Offshore", "offshore", p1),
        ("CCU-2202", "ccu", "Aveon", "AV-CCU-2202", d(-300), "good", "Aveon", "at_aveon", p2),
        ("TANK-3301", "tank", "Libroid", "LB-TK-3301", d(-100), "good", "Offshore", "offshore", p2),
        ("TANK-3302", "tank", "Libroid", "LB-TK-3302", d(-100), "good", "ACPML", "at_acpml", p2),
        ("IBC-4401", "ibc", "ACPML", "AC-IBC-4401", d(-60), "good", "ACPML", "ready_for_collection", p2),
        ("IBC-4402", "ibc", "ACPML", "AC-IBC-4402", d(-60), "good", "Libroid", "available", None),
        ("BSK-5501", "basket", "Aveon", "AV-BSK-5501", d(-120), "good", "Offshore", "offshore", p1),
        ("BSK-5502", "basket", "Aveon", "AV-BSK-5502", d(-120), "good", "Libroid", "returned", None),
    ]
    eq_ids = {}
    for code, etype, owner, serial, cert, cond, loc, status, proj in equipment:
        eid = execute(
            "INSERT INTO equipment (equipment_id, equipment_type, owner_name, serial_number, "
            "certification_expiry, condition, current_location, current_status, current_project_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (code, etype, owner, serial, cert, cond, loc, status, proj),
        )
        eq_ids[code] = eid

    # --- Movements: the worked example from the brief -------------------
    # Project -> Equipment -> Truck -> CWCTN -> Waste Disposal Certificate ->
    # Photos -> Invoices -> Weight Tickets -> Waybills -> EDNs
    chain = [
        ("AIMM01WS", "dispatch", "Libroid", "Offshore", "offshore", d(20), "Dispatched to field on EDN 000041"),
        ("AIMM02WS", "dispatch", "Libroid", "Offshore", "offshore", d(19), "Dispatched to field on EDN 000042"),
        ("AIMM02WS", "backload", "Offshore", "Aveon", "at_aveon", d(9), "Backloaded ex-Bonga, PSV manifest #PSV-1187"),
        ("AIMM02WS", "delivery", "Aveon", "ACPML", "at_acpml", d(7), "Waybill WB-5521 — delivered to ACPML for processing"),
        ("AIMM03WS", "dispatch", "Libroid", "Offshore", "offshore", d(30), "Dispatched to field"),
        ("AIMM03WS", "backload", "Offshore", "Aveon", "at_aveon", d(12), "Backloaded ex-Bonga"),
        ("AIMM03WS", "delivery", "Aveon", "ACPML", "at_acpml", d(10), "Waybill WB-5498 — delivered to ACPML"),
        ("AIMM03WS", "cleaning", "ACPML", "ACPML", "cleaning", d(2), "Skip cleaning in progress at ACPML"),
        ("AIMM04WS", "dispatch", "Libroid", "Offshore", "offshore", d(25), "Dispatched to field"),
        ("AIMM04WS", "backload", "Offshore", "Aveon", "at_aveon", d(3), "Backloaded ex-Bonga, awaiting onward waybill"),
        ("AIMM05WS", "dispatch", "Libroid", "Offshore", "offshore", d(40), "Dispatched to field"),
        ("AIMM05WS", "backload", "Offshore", "Aveon", "at_aveon", d(16), "Backloaded ex-Bonga"),
        ("AIMM05WS", "delivery", "Aveon", "ACPML", "at_acpml", d(15), "Waybill WB-5310 — delivered to ACPML"),
        ("AIMM05WS", "damage_report", "ACPML", "ACPML", "at_acpml", d(14), "Damage noted on receipt at ACPML — dented frame"),
        ("AIMM06WS", "return", "ACPML", "Libroid", "ready_for_collection", d(4), "Cleaned skip staged, ready for collection ERN pending"),
        ("AIMM07WS", "return", "ACPML", "Libroid", "returned", d(1), "Equipment Return Note ERN-3391 completed, back at Libroid"),
        ("BSK-5502", "return", "ACPML", "Libroid", "returned", d(1), "Basket returned, ERN-3392 completed"),
    ]
    for code, mtype, frm, to, status, occurred, notes in chain:
        execute(
            "INSERT INTO movements (equipment_id, project_id, movement_type, from_location, to_location, "
            "new_status, occurred_at, recorded_by, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (eq_ids[code], p1, mtype, frm, to, status, occurred + " 09:00:00", "Ops Team", notes),
        )

    # --- Documents --------------------------------------------------------
    def add_doc(project, doc_type, number, counterparty, status, issued, due, signed=None, signed_by=None,
                equipment_codes=None, notes=None):
        did = execute(
            "INSERT INTO documents (project_id, doc_type, doc_number, counterparty, status, issued_date, "
            "due_date, signed_date, signed_by, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (project, doc_type, number, counterparty, status, issued, due, signed, signed_by, notes),
        )
        for code in equipment_codes or []:
            execute("INSERT INTO doc_equipment (document_id, equipment_id) VALUES (?, ?)", (did, eq_ids[code]))
        return did

    add_doc(p1, "EDN", "EDN-000041", "MB&C", "completed", d(20), d(20), d(20), "Joachim (MB&C)", ["AIMM01WS"])
    add_doc(p1, "EDN", "EDN-000042", "MB&C", "completed", d(19), d(19), d(19), "Joachim (MB&C)", ["AIMM02WS"])
    add_doc(p1, "EDN", "EDN-000058", "MB&C", "pending_signature", d(1), d(2), None, None, ["AIMM04WS"],
            "Awaiting Joachim's signature at MB&C")
    manifest = add_doc(p1, "MANIFEST", "PSV-1187", "MB&C", "completed", d(9), d(9), d(9), "PSV Master",
                        ["AIMM02WS"])
    add_doc(p1, "WAYBILL", "WB-5521", "ACPML", "completed", d(7), d(7), d(7), "ACPML Gate", ["AIMM02WS"])
    add_doc(p1, "WAYBILL", "WB-5498", "ACPML", "completed", d(10), d(10), d(10), "ACPML Gate", ["AIMM03WS"])
    add_doc(p1, "WAYBILL", "WB-5310", "ACPML", "completed", d(15), d(15), d(15), "ACPML Gate", ["AIMM05WS"])
    cwctn1 = add_doc(p1, "CWCTN", "CWCTN-000051", "MB&C", "pending_signature", d(7), d(1), None, None,
                      ["AIMM02WS"], "Awaiting MB&C signature")
    cwctn2 = add_doc(p1, "CWCTN", "CWCTN-000052", "MB&C", "pending_signature", d(10), d(3), None, None,
                      ["AIMM03WS"], "Awaiting MB&C signature")
    add_doc(p1, "CWCTN", "CWCTN-000050", "MB&C", "completed", d(15), d(15), d(14), "Joachim (MB&C)", ["AIMM05WS"])
    add_doc(p1, "WEIGHT_TICKET", "WT-7701", "ACPML", "completed", d(7), d(7), d(7), "ACPML Weighbridge",
            ["AIMM02WS"])
    add_doc(p1, "WEIGHT_TICKET", "WT-7702", "ACPML", "completed", d(10), d(10), d(10), "ACPML Weighbridge",
            ["AIMM03WS"])
    add_doc(p1, "WASTE_DISPOSAL_CERT", "WDC-9001", "ACPML", "completed", d(6), d(6), d(6), "ACPML Compliance",
            ["AIMM02WS"])
    add_doc(p1, "WASTE_DISPOSAL_CERT", "WDC-9002", "ACPML", "pending_signature", d(10), d(1), None, None,
            ["AIMM03WS"], "Disposal certificate outstanding from ACPML")
    add_doc(p1, "ERN", "ERN-3391", "Libroid", "completed", d(1), d(1), d(1), "Libroid Store", ["AIMM07WS"])
    add_doc(p1, "ERN", "ERN-3392", "Libroid", "completed", d(1), d(1), d(1), "Libroid Store", ["BSK-5502"])
    add_doc(p1, "ERN", "ERN-3393", "Libroid", "pending_signature", d(4), d(0), None, None, ["AIMM06WS"],
            "Awaiting Libroid sign-off before collection")

    add_doc(p2, "CWCTN", "CWCTN-000060", "Blue Gretha", "pending_signature", d(3), d(1), None, None,
            ["TANK-3302"], "Reconcile against Blue Gretha manifest")
    add_doc(p2, "MANIFEST", "BG-MANIFEST-04", "Blue Gretha", "completed", d(9), d(9), d(9), "Vessel Master",
            ["TANK-3301"])

    # --- Waste transactions ------------------------------------------------
    execute(
        "INSERT INTO waste_transactions (project_id, equipment_id, waste_type, gross_weight_kg, tare_weight_kg, "
        "net_weight_kg, collection_date, processing_date, disposal_date, certificate_document_id, status) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (p1, eq_ids["AIMM02WS"], "hazardous", 4200, 900, 3300, d(7), d(6), d(6), None, "certified"),
    )
    execute(
        "INSERT INTO waste_transactions (project_id, equipment_id, waste_type, gross_weight_kg, tare_weight_kg, "
        "net_weight_kg, collection_date, processing_date, disposal_date, certificate_document_id, status) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (p1, eq_ids["AIMM03WS"], "hazardous", 3900, 850, 3050, d(10), d(9), None, None, "processing"),
    )
    execute(
        "INSERT INTO waste_transactions (project_id, equipment_id, waste_type, gross_weight_kg, tare_weight_kg, "
        "net_weight_kg, collection_date, processing_date, disposal_date, certificate_document_id, status) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (p1, eq_ids["AIMM05WS"], "non-hazardous", 2100, 700, 1400, d(15), d(14), d(13), None, "certified"),
    )

    # --- Invoices ------------------------------------------------------------
    inv1 = execute(
        "INSERT INTO invoices (invoice_number, project_id, invoice_type, party_name, issue_date, due_date, "
        "subtotal, vat_rate, vat_amount, total, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        ("FD-INV-2026-0031", p1, "client", "MB&C", d(6), d(-24), 0, 7.5, 0, 0, "sent"),
    )
    items1 = [
        (inv1, "Skip hire and logistics — AIMM02WS (Offshore-Aveon-ACPML cycle)", 1, 185000, "AIMM02WS"),
        (inv1, "Waste collection, processing & disposal — 3.3t hazardous waste (WDC-9001)", 1, 240000, None),
        (inv1, "CWCTN & waybill administration", 1, 35000, None),
    ]
    subtotal1 = 0
    for _, desc, qty, unit_price, code in items1:
        amount = qty * unit_price
        subtotal1 += amount
        execute(
            "INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, amount, equipment_id) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (inv1, desc, qty, unit_price, amount, eq_ids.get(code) if code else None),
        )
    vat1 = round(subtotal1 * 0.075, 2)
    execute("UPDATE invoices SET subtotal=?, vat_amount=?, total=? WHERE id=?",
            (subtotal1, vat1, subtotal1 + vat1, inv1))

    inv2 = execute(
        "INSERT INTO invoices (invoice_number, project_id, invoice_type, party_name, issue_date, due_date, "
        "subtotal, vat_rate, vat_amount, total, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        ("FD-VEND-2026-0014", p1, "vendor", "Libroid", d(1), d(-29), 0, 7.5, 0, 0, "draft"),
    )
    items2 = [
        (inv2, "Skip rental — AIMM07WS, returned in good condition (ERN-3391)", 1, 45000, "AIMM07WS"),
        (inv2, "Basket rental — BSK-5502 (ERN-3392)", 1, 32000, "BSK-5502"),
    ]
    subtotal2 = 0
    for _, desc, qty, unit_price, code in items2:
        amount = qty * unit_price
        subtotal2 += amount
        execute(
            "INSERT INTO invoice_items (invoice_id, description, quantity, unit_price, amount, equipment_id) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (inv2, desc, qty, unit_price, amount, eq_ids.get(code) if code else None),
        )
    vat2 = round(subtotal2 * 0.075, 2)
    execute("UPDATE invoices SET subtotal=?, vat_amount=?, total=? WHERE id=?",
            (subtotal2, vat2, subtotal2 + vat2, inv2))

    print("Seed complete.")
    print(f"  Projects: {len(query('SELECT id FROM projects'))}")
    print(f"  Equipment: {len(query('SELECT id FROM equipment'))}")
    print(f"  Documents: {len(query('SELECT id FROM documents'))}")
    print(f"  Movements: {len(query('SELECT id FROM movements'))}")
    print(f"  Invoices: {len(query('SELECT id FROM invoices'))}")
    print(f"  Login: {admin_email} / {admin_password}")


if __name__ == "__main__":
    run()
