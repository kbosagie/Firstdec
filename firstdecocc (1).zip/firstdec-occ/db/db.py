"""SQLite connection helpers for the FIRSTDEC Operations Control Centre.

Kept deliberately as thin, explicit SQL rather than an ORM so the schema in
schema.sql is the single source of truth and the whole data layer can be
migrated to PostgreSQL later by swapping this module (see README).
"""
import os
import sqlite3

from config import DATA_DIR

DB_PATH = os.path.join(DATA_DIR, "instance", "firstdec.db")
SCHEMA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema.sql")


def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(reset=False):
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = get_connection()
    with open(SCHEMA_PATH, "r") as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()


def query(sql, params=(), one=False):
    conn = get_connection()
    try:
        cur = conn.execute(sql, params)
        rows = cur.fetchall()
        return (rows[0] if rows else None) if one else rows
    finally:
        conn.close()


def execute(sql, params=()):
    conn = get_connection()
    try:
        cur = conn.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    finally:
        conn.close()


def executemany(sql, seq_of_params):
    conn = get_connection()
    try:
        conn.executemany(sql, seq_of_params)
        conn.commit()
    finally:
        conn.close()
