-- FIRSTDEC Operations Control Centre — SQLite schema
-- Core principle: everything revolves around Project ID + Equipment ID.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'ops',           -- admin | ops | viewer
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,                  -- e.g. MBC-BONGA
    name TEXT NOT NULL,                         -- e.g. MB&C Bonga Project
    client_name TEXT NOT NULL,                  -- e.g. MB&C
    status TEXT NOT NULL DEFAULT 'active',      -- active | completed | on_hold
    start_date TEXT,
    end_date TEXT,
    description TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS equipment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    equipment_id TEXT UNIQUE NOT NULL,          -- e.g. AIMM01WS
    equipment_type TEXT NOT NULL,               -- skip | tank | ccu | ibc | basket
    owner_name TEXT NOT NULL,                   -- vendor / equipment owner, e.g. Libroid
    serial_number TEXT,
    certification_expiry TEXT,
    condition TEXT NOT NULL DEFAULT 'good',     -- good | damaged | under_repair
    current_location TEXT NOT NULL DEFAULT 'Libroid',
    current_status TEXT NOT NULL DEFAULT 'available',
        -- available | on_hire | offshore | at_aveon | at_acpml | cleaning |
        -- ready_for_collection | returned | damaged
    current_project_id INTEGER REFERENCES projects(id),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    equipment_id INTEGER NOT NULL REFERENCES equipment(id),
    project_id INTEGER REFERENCES projects(id),
    movement_type TEXT NOT NULL,                -- dispatch|offshore_load|backload|delivery|return|cleaning|damage_report
    from_location TEXT,
    to_location TEXT NOT NULL,
    new_status TEXT,
    occurred_at TEXT NOT NULL DEFAULT (datetime('now')),
    recorded_by TEXT,
    notes TEXT,
    photo_path TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER REFERENCES projects(id),
    doc_type TEXT NOT NULL,                     -- EDN|ERN|CWCTN|WASTE_DISPOSAL_CERT|WAYBILL|MANIFEST|WEIGHT_TICKET|OTHER
    doc_number TEXT,
    counterparty TEXT,                          -- who needs to sign / issued to, e.g. MB&C, ACPML
    status TEXT NOT NULL DEFAULT 'pending_signature',
        -- draft|pending_signature|signed|completed|rejected
    issued_date TEXT,
    due_date TEXT,
    signed_date TEXT,
    signed_by TEXT,
    file_path TEXT,
    extracted_json TEXT,                        -- raw OCR-extracted fields, JSON
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS doc_equipment (
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    equipment_id INTEGER NOT NULL REFERENCES equipment(id),
    PRIMARY KEY (document_id, equipment_id)
);

CREATE TABLE IF NOT EXISTS waste_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER REFERENCES projects(id),
    equipment_id INTEGER REFERENCES equipment(id),
    waste_type TEXT NOT NULL,                   -- e.g. hazardous, non-hazardous, oily waste
    gross_weight_kg REAL,
    tare_weight_kg REAL,
    net_weight_kg REAL,
    collection_date TEXT,
    processing_date TEXT,
    disposal_date TEXT,
    certificate_document_id INTEGER REFERENCES documents(id),
    status TEXT NOT NULL DEFAULT 'collected',   -- collected|processing|disposed|certified
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS invoices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_number TEXT UNIQUE NOT NULL,
    project_id INTEGER REFERENCES projects(id),
    invoice_type TEXT NOT NULL DEFAULT 'client', -- client|vendor
    party_name TEXT NOT NULL,
    issue_date TEXT NOT NULL,
    due_date TEXT,
    subtotal REAL NOT NULL DEFAULT 0,
    vat_rate REAL NOT NULL DEFAULT 7.5,
    vat_amount REAL NOT NULL DEFAULT 0,
    total REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'draft',        -- draft|sent|paid|overdue
    notes TEXT,
    pdf_path TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS invoice_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    quantity REAL NOT NULL DEFAULT 1,
    unit_price REAL NOT NULL DEFAULT 0,
    amount REAL NOT NULL DEFAULT 0,
    equipment_id INTEGER REFERENCES equipment(id),
    document_id INTEGER REFERENCES documents(id)
);

CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reminder_key TEXT UNIQUE NOT NULL,           -- stable business key to dedupe on refresh
    reminder_type TEXT NOT NULL,
        -- unsigned_edn|unsigned_cwctn|outstanding_disposal_cert|cleaning_due|
        -- overdue_return|missing_document|cert_expiring
    project_id INTEGER REFERENCES projects(id),
    equipment_id INTEGER REFERENCES equipment(id),
    document_id INTEGER REFERENCES documents(id),
    message TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'orange',     -- red|orange|green
    due_date TEXT,
    status TEXT NOT NULL DEFAULT 'open',         -- open|resolved
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,
    entity_id INTEGER,
    action TEXT NOT NULL,
    detail TEXT,
    actor TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_equipment_status ON equipment(current_status);
CREATE INDEX IF NOT EXISTS idx_equipment_project ON equipment(current_project_id);
CREATE INDEX IF NOT EXISTS idx_movements_equipment ON movements(equipment_id);
CREATE INDEX IF NOT EXISTS idx_documents_project ON documents(project_id);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_reminders_status ON reminders(status);
