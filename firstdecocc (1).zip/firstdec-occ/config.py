"""Central place for where FIRSTDEC OCC keeps its persistent data (the SQLite
database, uploaded documents, generated invoice/report PDFs).

By default everything lives inside the project folder (instance/, uploads/,
exports/) — fine for running locally. On a host with an ephemeral filesystem
(most PaaS platforms redeploy into a fresh container), set FIRSTDEC_DATA_DIR
to a mounted persistent-disk path (e.g. /var/data) so the database and
uploaded files survive restarts and redeploys.
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("FIRSTDEC_DATA_DIR", BASE_DIR)
