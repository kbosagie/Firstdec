import os

from flask import Flask, session, redirect, url_for, request, g

from config import DATA_DIR
from db.db import init_db, DB_PATH


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-secret-change-me")
    app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024  # 25MB uploads
    app.config["UPLOAD_DIR"] = os.path.join(DATA_DIR, "uploads")
    os.makedirs(app.config["UPLOAD_DIR"], exist_ok=True)

    if not os.path.exists(DB_PATH):
        if os.environ.get("FIRSTDEC_SKIP_SEED") == "1":
            init_db()
        else:
            # First boot on a fresh database (e.g. a new persistent disk on a cloud
            # host): seed the MB&C Bonga demo dataset so the app is immediately
            # explorable. Set FIRSTDEC_SKIP_SEED=1 to start from an empty schema
            # instead once you're ready to load real operational data.
            from db.seed import run as seed_run
            seed_run()

    from routes.auth import auth_bp, login_required
    from routes.dashboard import dashboard_bp
    from routes.equipment import equipment_bp
    from routes.projects import projects_bp
    from routes.documents import documents_bp
    from routes.invoices import invoices_bp
    from routes.reports import reports_bp
    from routes.assistant import assistant_bp
    from routes.scan import scan_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(equipment_bp)
    app.register_blueprint(projects_bp)
    app.register_blueprint(documents_bp)
    app.register_blueprint(invoices_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(assistant_bp)
    app.register_blueprint(scan_bp)

    from services.text_format import friendly_label
    app.add_template_filter(friendly_label, name="friendly")

    PUBLIC_ENDPOINTS = {"auth.login", "static", "scan.scan_equipment", "scan.scan_update"}

    @app.before_request
    def require_login():
        if request.endpoint is None:
            return None
        if request.endpoint in PUBLIC_ENDPOINTS:
            return None
        if not session.get("user_id"):
            return redirect(url_for("auth.login", next=request.path))
        return None

    @app.context_processor
    def inject_globals():
        return {"current_user_name": session.get("user_name")}

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "1") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug)
