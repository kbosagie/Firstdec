import os
import uuid

from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app

from db.db import query, execute
from services.dashboard_stats import STATUS_LABELS

scan_bp = Blueprint("scan", __name__, url_prefix="/scan")

LOCATIONS = ["Libroid", "Aveon", "Offshore", "ACPML", "Client Site"]
STATUS_OPTIONS = list(STATUS_LABELS.items())


@scan_bp.route("/<code>")
def scan_equipment(code):
    eq = query("SELECT e.*, p.name AS project_name FROM equipment e "
               "LEFT JOIN projects p ON p.id = e.current_project_id WHERE e.equipment_id = ?",
               (code,), one=True)
    if not eq:
        return render_template("scan.html", eq=None, code=code, locations=LOCATIONS,
                               status_options=STATUS_OPTIONS)
    last_movements = query(
        "SELECT * FROM movements WHERE equipment_id = ? ORDER BY occurred_at DESC LIMIT 5", (eq["id"],)
    )
    return render_template("scan.html", eq=eq, code=code, last_movements=last_movements,
                           locations=LOCATIONS, status_options=STATUS_OPTIONS)


@scan_bp.route("/<code>/update", methods=["POST"])
def scan_update(code):
    eq = query("SELECT * FROM equipment WHERE equipment_id = ?", (code,), one=True)
    if not eq:
        flash("Equipment not found.", "error")
        return redirect(url_for("scan.scan_equipment", code=code))

    f = request.form
    to_location = f.get("to_location", eq["current_location"])
    new_status = f.get("new_status", eq["current_status"])
    recorded_by = f.get("recorded_by", "Field Update")
    notes = f.get("notes", "")

    photo_path = None
    photo = request.files.get("photo")
    if photo and photo.filename:
        ext = os.path.splitext(photo.filename)[1].lower()
        stored_name = f"movement_{uuid.uuid4().hex}{ext}"
        photo_path = os.path.join(current_app.config["UPLOAD_DIR"], stored_name)
        photo.save(photo_path)

    execute(
        "INSERT INTO movements (equipment_id, project_id, movement_type, from_location, to_location, "
        "new_status, recorded_by, notes, photo_path) VALUES (?, ?, 'field_update', ?, ?, ?, ?, ?, ?)",
        (eq["id"], eq["current_project_id"], eq["current_location"], to_location, new_status, recorded_by,
         notes, photo_path),
    )
    execute("UPDATE equipment SET current_location = ?, current_status = ? WHERE id = ?",
            (to_location, new_status, eq["id"]))

    flash(f"Thanks — {code} logged at {to_location} ({new_status.replace('_', ' ')}).", "success")
    return redirect(url_for("scan.scan_equipment", code=code))
