from flask import Blueprint, render_template, request, redirect, url_for, flash

from db.db import query, execute
from services.dashboard_stats import STATUS_LABELS

projects_bp = Blueprint("projects", __name__, url_prefix="/projects")


@projects_bp.route("/")
def list_projects():
    rows = query("SELECT * FROM projects ORDER BY status = 'active' DESC, name")
    counts = {r["current_project_id"]: r["c"] for r in query(
        "SELECT current_project_id, COUNT(*) c FROM equipment WHERE current_project_id IS NOT NULL "
        "GROUP BY current_project_id"
    )}
    return render_template("projects_list.html", projects=rows, equipment_counts=counts)


@projects_bp.route("/new", methods=["POST"])
def new_project():
    f = request.form
    execute(
        "INSERT INTO projects (code, name, client_name, status, start_date, description) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (f["code"].strip().upper(), f["name"], f["client_name"], f.get("status", "active"),
         f.get("start_date"), f.get("description")),
    )
    flash(f"Project {f['code'].upper()} created.", "success")
    return redirect(url_for("projects.list_projects"))


@projects_bp.route("/<int:project_id>")
def detail(project_id):
    project = query("SELECT * FROM projects WHERE id = ?", (project_id,), one=True)
    if not project:
        flash("Project not found.", "error")
        return redirect(url_for("projects.list_projects"))

    equipment = query(
        "SELECT * FROM equipment WHERE current_project_id = ? ORDER BY equipment_id", (project_id,),
    )
    documents = query(
        "SELECT * FROM documents WHERE project_id = ? ORDER BY issued_date DESC", (project_id,),
    )
    movements = query(
        "SELECT m.*, e.equipment_id AS equipment_code FROM movements m "
        "JOIN equipment e ON e.id = m.equipment_id WHERE m.project_id = ? "
        "ORDER BY m.occurred_at DESC LIMIT 50", (project_id,),
    )
    invoices = query("SELECT * FROM invoices WHERE project_id = ? ORDER BY issue_date DESC", (project_id,))
    waste = query(
        "SELECT w.*, e.equipment_id AS equipment_code FROM waste_transactions w "
        "LEFT JOIN equipment e ON e.id = w.equipment_id WHERE w.project_id = ? ORDER BY collection_date DESC",
        (project_id,),
    )
    return render_template(
        "project_detail.html", project=project, equipment=equipment, documents=documents,
        movements=movements, invoices=invoices, waste=waste, status_labels=STATUS_LABELS,
    )
