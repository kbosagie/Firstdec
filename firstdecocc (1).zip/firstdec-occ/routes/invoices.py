from datetime import datetime, timedelta

from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file

from db.db import query, execute
from services.invoices import create_invoice, get_invoice, generate_invoice_pdf, DEFAULT_VAT_RATE

invoices_bp = Blueprint("invoices", __name__, url_prefix="/invoices")


@invoices_bp.route("/")
def list_invoices():
    rows = query(
        "SELECT i.*, p.name AS project_name FROM invoices i LEFT JOIN projects p ON p.id = i.project_id "
        "ORDER BY i.created_at DESC"
    )
    return render_template("invoices_list.html", invoices=rows)


@invoices_bp.route("/new", methods=["GET", "POST"])
def new_invoice():
    if request.method == "POST":
        f = request.form
        descriptions = request.form.getlist("item_description")
        quantities = request.form.getlist("item_quantity")
        unit_prices = request.form.getlist("item_unit_price")
        equipment_codes = request.form.getlist("item_equipment_id")

        items = []
        for desc, qty, price, code in zip(descriptions, quantities, unit_prices, equipment_codes):
            if not desc.strip():
                continue
            eq = query("SELECT id FROM equipment WHERE equipment_id = ?", (code,), one=True) if code else None
            items.append({
                "description": desc.strip(),
                "quantity": float(qty or 1),
                "unit_price": float(price or 0),
                "equipment_id": eq["id"] if eq else None,
            })
        if not items:
            flash("Add at least one line item.", "error")
            return redirect(url_for("invoices.new_invoice"))

        invoice_id = create_invoice(
            project_id=f.get("project_id") or None,
            invoice_type=f["invoice_type"],
            party_name=f["party_name"],
            issue_date=f.get("issue_date") or datetime.now().strftime("%Y-%m-%d"),
            due_date=f.get("due_date") or (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d"),
            items=items,
            vat_rate=float(f.get("vat_rate") or DEFAULT_VAT_RATE),
            notes=f.get("notes"),
        )
        flash("Invoice created.", "success")
        return redirect(url_for("invoices.detail", invoice_id=invoice_id))

    projects = query("SELECT * FROM projects ORDER BY status='active' DESC, name")
    equipment = query("SELECT equipment_id, owner_name, equipment_type FROM equipment ORDER BY equipment_id")
    return render_template("invoice_form.html", projects=projects, equipment=equipment,
                           default_vat=DEFAULT_VAT_RATE, today=datetime.now().strftime("%Y-%m-%d"))


@invoices_bp.route("/<int:invoice_id>")
def detail(invoice_id):
    invoice, items = get_invoice(invoice_id)
    if not invoice:
        flash("Invoice not found.", "error")
        return redirect(url_for("invoices.list_invoices"))
    return render_template("invoice_detail.html", invoice=invoice, items=items)


@invoices_bp.route("/<int:invoice_id>/status", methods=["POST"])
def update_status(invoice_id):
    execute("UPDATE invoices SET status = ? WHERE id = ?", (request.form["status"], invoice_id))
    flash("Invoice status updated.", "success")
    return redirect(url_for("invoices.detail", invoice_id=invoice_id))


@invoices_bp.route("/<int:invoice_id>/pdf")
def pdf(invoice_id):
    path = generate_invoice_pdf(invoice_id)
    return send_file(path, as_attachment=False)
