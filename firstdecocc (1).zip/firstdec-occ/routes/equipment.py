import io

from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file, session

from db.db import query, execute
from services.dashboard_stats import STATUS_LABELS
from services.qr import generate_qr_image

equipment_bp = Blueprint("equipment", __name__, url_prefix="/equipment")


@equipment_bp.route("/")
def list_equipment():
    etype = request.args.get("type", "")
    status = request.args.get("status", "")
    owner = request.args.get("owner", "")
    search = request.args.get("q", "")

    sql = ("SELECT e.*, p.name AS project_name FROM equipment e "
           "LEFT JOIN projects p ON p.id = e.current_project_id WHERE 1=1")
    params = []
    if etype:
        sql += " AND e.equipment_type = ?"
        params.append(etype)
    if status:
        sql += " AND e.current_status = ?"
        params.append(status)
    if owner:
        sql += " AND e.owner_name = ?"
        params.append(owner)
    if search:
        sql += " AND e.equipment_id LIKE ?"
        params.append(f"%{search.upper()}%")
    sql += " ORDER BY e.equipment_id"

    rows = query(sql, tuple(params))
    owners = [r["owner_name"] for r in query("SELECT DISTINCT owner_name FROM equipment ORDER BY 1")]
    types = [r["equipment_type"] for r in query("SELECT DISTINCT equipment_type FROM equipment ORDER BY 1")]
    return render_template(
        "equipment_list.html", equipment=rows, owners=owners, types=types,
        status_labels=STATUS_LABELS, filters={"type": etype, "status": status, "owner": owner, "q": search},
    )


@equipment_bp.route("/new", methods=["GET", "POST"])
def new_equipment():
    if request.method == "POST":
        f = request.form
        execute(
            "INSERT INTO equipment (equipment_id, equipment_type, owner_name, serial_number, "
            "certification_expiry, condition, current_location, current_status, current_project_id, notes) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (f["equipment_id"].strip().upper(), f["equipment_type"], f["owner_name"], f.get("serial_number"),
             f.get("certification_expiry") or None, f.get("condition", "good"),
             f.get("current_location", "Libroid"), f.get("current_status", "available"),
             f.get("current_project_id") or None, f.get("notes")),
        )
        flash(f"Equipment {f['equipment_id'].upper()} registered.", "success")
        return redirect(url_for("equipment.list_equipment"))
    projects = query("SELECT * FROM projects WHERE status='active' ORDER BY name")
    return render_template("equipment_form.html", projects=projects, equipment=None,
                           status_labels=STATUS_LABELS)


@equipment_bp.route("/<code>")
def detail(code):
    eq = query("SELECT e.*, p.name AS project_name, p.code AS project_code FROM equipment e "
               "LEFT JOIN projects p ON p.id = e.current_project_id WHERE e.equipment_id = ?",
               (code,), one=True)
    if not eq:
        flash("Equipment not found.", "error")
        return redirect(url_for("equipment.list_equipment"))

    movements = query(
        "SELECT m.*, p.name AS project_name FROM movements m LEFT JOIN projects p ON p.id = m.project_id "
        "WHERE m.equipment_id = ? ORDER BY m.occurred_at DESC", (eq["id"],),
    )
    documents = query(
        "SELECT d.* FROM documents d JOIN doc_equipment de ON de.document_id = d.id "
        "WHERE de.equipment_id = ? ORDER BY d.issued_date DESC", (eq["id"],),
    )
    waste = query("SELECT * FROM waste_transactions WHERE equipment_id = ? ORDER BY collection_date DESC",
                  (eq["id"],))
    projects = query("SELECT * FROM projects ORDER BY name")
    return render_template(
        "equipment_detail.html", eq=eq, movements=movements, documents=documents, waste=waste,
        projects=projects, status_labels=STATUS_LABELS,
    )


@equipment_bp.route("/<code>/movement", methods=["POST"])
def log_movement(code):
    eq = query("SELECT * FROM equipment WHERE equipment_id = ?", (code,), one=True)
    if not eq:
        flash("Equipment not found.", "error")
        return redirect(url_for("equipment.list_equipment"))
    f = request.form
    new_status = f["new_status"]
    to_location = f["to_location"]
    execute(
        "INSERT INTO movements (equipment_id, project_id, movement_type, from_location, to_location, "
        "new_status, recorded_by, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (eq["id"], eq["current_project_id"], f["movement_type"], eq["current_location"], to_location,
         new_status, session.get("user_name", "Ops"), f.get("notes")),
    )
    execute(
        "UPDATE equipment SET current_location = ?, current_status = ? WHERE id = ?",
        (to_location, new_status, eq["id"]),
    )
    flash(f"{code} updated: now {new_status.replace('_', ' ')} at {to_location}.", "success")
    return redirect(url_for("equipment.detail", code=code))


@equipment_bp.route("/<code>/edit", methods=["POST"])
def edit_equipment(code):
    eq = query("SELECT * FROM equipment WHERE equipment_id = ?", (code,), one=True)
    if not eq:
        flash("Equipment not found.", "error")
        return redirect(url_for("equipment.list_equipment"))
    f = request.form
    execute(
        "UPDATE equipment SET equipment_type=?, owner_name=?, serial_number=?, certification_expiry=?, "
        "condition=?, current_project_id=?, notes=? WHERE id=?",
        (f["equipment_type"], f["owner_name"], f.get("serial_number"), f.get("certification_expiry") or None,
         f.get("condition"), f.get("current_project_id") or None, f.get("notes"), eq["id"]),
    )
    flash(f"{code} profile updated.", "success")
    return redirect(url_for("equipment.detail", code=code))


@equipment_bp.route("/<code>/qr.png")
def qr_image(code):
    base_url = request.url_root
    img = generate_qr_image(f"{base_url.rstrip('/')}/scan/{code}")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")
