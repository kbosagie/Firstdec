from flask import Blueprint, render_template

from db.db import query
from services.dashboard_stats import get_dashboard_stats, get_recent_movements
from services.reminders import refresh_reminders, get_open_reminders

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
def index():
    refresh_reminders()
    stats = get_dashboard_stats()
    reminders = get_open_reminders()
    recent_movements = get_recent_movements(12)
    projects = query("SELECT * FROM projects WHERE status = 'active' ORDER BY name")
    return render_template(
        "dashboard.html", stats=stats, reminders=reminders,
        recent_movements=recent_movements, projects=projects,
    )
