from flask import Blueprint, render_template, request, jsonify

from services.assistant import answer_query

assistant_bp = Blueprint("assistant", __name__, url_prefix="/assistant")


@assistant_bp.route("/")
def index():
    return render_template("assistant.html")


@assistant_bp.route("/ask", methods=["POST"])
def ask():
    text = request.json.get("query", "") if request.is_json else request.form.get("query", "")
    result = answer_query(text)
    return jsonify(result)
