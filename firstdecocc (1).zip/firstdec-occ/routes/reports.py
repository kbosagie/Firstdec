from flask import Blueprint, render_template, request, send_file

from db.db import query
from services.reports import build_report, generate_report_pdf

reports_bp = Blueprint("reports", __name__, url_prefix="/reports")


@reports_bp.route("/")
def index():
    projects = query("SELECT * FROM projects ORDER BY status='active' DESC, name")
    period = request.args.get("period", "daily")
    project_id = request.args.get("project_id", type=int)
    report = build_report(period, project_id)
    return render_template("reports.html", report=report, projects=projects,
                           selected_period=period, selected_project_id=project_id)


@reports_bp.route("/pdf")
def pdf():
    period = request.args.get("period", "daily")
    project_id = request.args.get("project_id", type=int)
    report = build_report(period, project_id)
    path = generate_report_pdf(report)
    return send_file(path, as_attachment=False)
