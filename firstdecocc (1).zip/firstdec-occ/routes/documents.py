import json
import os
import uuid

from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, send_from_directory

from db.db import query, execute
from services.ocr import extract_fields

documents_bp = Blueprint("documents", __name__, url_prefix="/documents")

ALLOWED_EXT = {".pdf", ".png", ".jpg", ".jpeg", ".tiff", ".bmp"}
DOC_TYPES = ["EDN", "ERN", "CWCTN", "WASTE_DISPOSAL_CERT", "WAYBILL", "MANIFEST", "WEIGHT_TICKET", "OTHER"]


@documents_bp.route("/")
def list_documents():
    doc_type = request.args.get("type", "")
    status = request.args.get("status", "")
    project_id = request.args.get("project_id", "")

    sql = ("SELECT d.*, p.name AS project_name FROM documents d "
           "LEFT JOIN projects p ON p.id = d.project_id WHERE 1=1")
    params = []
    if doc_type:
        sql += " AND d.doc_type = ?"
        params.append(doc_type)
    if status:
        sql += " AND d.status = ?"
        params.append(status)
    if project_id:
        sql += " AND d.project_id = ?"
        params.append(project_id)
    sql += " ORDER BY d.created_at DESC"

    rows = query(sql, tuple(params))
    projects = query("SELECT * FROM projects ORDER BY name")
    return render_template("documents_list.html", documents=rows, doc_types=DOC_TYPES, projects=projects,
                           filters={"type": doc_type, "status": status, "project_id": project_id})


@documents_bp.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "GET":
        projects = query("SELECT * FROM projects WHERE status='active' ORDER BY name")
        return render_template("document_upload.html", projects=projects, doc_types=DOC_TYPES)

    file = request.files.get("file")
    project_id = request.form.get("project_id") or None
    if not file or file.filename == "":
        flash("Please choose a file to upload.", "error")
        return redirect(url_for("documents.upload"))

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in ALLOWED_EXT:
        flash("Unsupported file type. Use PDF, PNG or JPG.", "error")
        return redirect(url_for("documents.upload"))

    stored_name = f"{uuid.uuid4().hex}{ext}"
    stored_path = os.path.join(current_app.config["UPLOAD_DIR"], stored_name)
    file.save(stored_path)

    try:
        extracted = extract_fields(stored_path)
    except Exception as exc:
        extracted = {"raw_text_preview": f"(OCR failed: {exc})", "doc_type": None, "doc_number": None,
                     "equipment_ids": [], "dates": [], "weights": [], "quantity": None}

    matched_equipment = []
    if extracted["equipment_ids"]:
        placeholders = ",".join("?" * len(extracted["equipment_ids"]))
        matched_equipment = query(
            f"SELECT * FROM equipment WHERE equipment_id IN ({placeholders})",
            tuple(extracted["equipment_ids"]),
        )

    projects = query("SELECT * FROM projects ORDER BY status='active' DESC, name")
    return render_template(
        "document_confirm.html", extracted=extracted, stored_name=stored_name,
        original_name=file.filename, matched_equipment=matched_equipment, projects=projects,
        doc_types=DOC_TYPES, preselect_project=project_id,
    )


@documents_bp.route("/confirm", methods=["POST"])
def confirm():
    f = request.form
    stored_name = f["stored_name"]
    stored_path = os.path.join(current_app.config["UPLOAD_DIR"], stored_name)

    equipment_ids = set(request.form.getlist("equipment_ids"))
    extra = f.get("extra_equipment_ids", "")
    for token in extra.replace(",", " ").split():
        equipment_ids.add(token.strip().upper())

    document_id = execute(
        "INSERT INTO documents (project_id, doc_type, doc_number, counterparty, status, issued_date, "
        "due_date, file_path, extracted_json, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (f.get("project_id") or None, f["doc_type"], f.get("doc_number"), f.get("counterparty"),
         f.get("status", "pending_signature"), f.get("issued_date") or None, f.get("due_date") or None,
         stored_path, f.get("extracted_json"), f.get("notes")),
    )
    for eq_id in equipment_ids:
        eq = query("SELECT id FROM equipment WHERE equipment_id = ?", (eq_id,), one=True)
        if eq:
            execute("INSERT OR IGNORE INTO doc_equipment (document_id, equipment_id) VALUES (?, ?)",
                     (document_id, eq["id"]))

    flash(f"{f['doc_type']} {f.get('doc_number') or ''} saved.", "success")
    return redirect(url_for("documents.detail", document_id=document_id))


@documents_bp.route("/<int:document_id>")
def detail(document_id):
    doc = query("SELECT d.*, p.name AS project_name FROM documents d LEFT JOIN projects p ON p.id=d.project_id "
                "WHERE d.id = ?", (document_id,), one=True)
    if not doc:
        flash("Document not found.", "error")
        return redirect(url_for("documents.list_documents"))
    linked_equipment = query(
        "SELECT e.* FROM equipment e JOIN doc_equipment de ON de.equipment_id = e.id "
        "WHERE de.document_id = ?", (document_id,),
    )
    return render_template("document_detail.html", doc=doc, linked_equipment=linked_equipment)


@documents_bp.route("/<int:document_id>/mark", methods=["POST"])
def mark_status(document_id):
    new_status = request.form.get("status")
    signed_by = request.form.get("signed_by")
    if new_status in ("signed", "completed"):
        execute("UPDATE documents SET status=?, signed_date=date('now'), signed_by=? WHERE id=?",
                (new_status, signed_by, document_id))
    else:
        execute("UPDATE documents SET status=? WHERE id=?", (new_status, document_id))
    flash("Document status updated.", "success")
    return redirect(url_for("documents.detail", document_id=document_id))


@documents_bp.route("/file/<path:stored_name>")
def serve_upload(stored_name):
    return send_from_directory(current_app.config["UPLOAD_DIR"], stored_name)
